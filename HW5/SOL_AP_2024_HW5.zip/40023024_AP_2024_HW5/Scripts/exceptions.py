class ConstError(Exception):
    """Cannot modify this varibale"""
    pass