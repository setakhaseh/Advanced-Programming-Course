import aiohttp
import asyncio

async def fetch_data(session: aiohttp.ClientSession, url: str) -> dict:
    async with session.get(url) as response:
        if response.status == 200:
            return await response.json()
        else:
            raise aiohttp.ClientResponseError(
                f'Error status code: {response.status}', response.status
            )

async def main(urls: list[str]) -> list[dict]:
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_data(session, url) for url in urls]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        return [response for response in responses if not isinstance(response, Exception)]

# Example test
if __name__ == '__main__':
    urls = [
        'https://jsonplaceholder.typicode.com/posts/1',
        'https://jsonplaceholder.typicode.com/posts/2',
        'https://jsonplaceholder.typicode.com/posts/3'
    ]
    responses = asyncio.run(main(urls))
    for response in responses:
        print(response)