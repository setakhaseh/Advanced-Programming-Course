import functools

def reverse_string(func):
    """If output is a string, reverse it. Otherwise, return None."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        if isinstance(result, str):
            return result[::-1]
        else:
            return None
    return wrapper

@reverse_string
def get_university_name() -> str:
    return "Western Institute of Technology and Higher Education"

@reverse_string
def get_university_founding_year() -> int:
    return 1957

print(
    get_university_name(),
    get_university_founding_year(),
    sep="\n"
)

def is_prime(n: int) -> bool:
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

def prime_filter(func):
    """Given a list of integers, return only the prime integers."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        if isinstance(result, list):
            return [num for num in result if is_prime(num)]
        else:
            return []
    return wrapper

@prime_filter
def numbers(from_num: int, to_num: int) -> list[int]:
    return [num for num in range(from_num, to_num)]

print(numbers(from_num=2, to_num=20))
import random

def choose_one(func):
    """Given a list of elements, select a random one."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        if isinstance(result, list) and len(result) > 0:
            return random.choice(result)
        else:
            return None
    return wrapper

@choose_one
def available_options() -> list[str]:
    return ["A", "B", "C"]

print(available_options())
import functools
import random

def power(n: int):
    """Given a number, return a tuple where the first element is the
    original number and the second is the nth power."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            return (result, result ** n)
        return wrapper
    return decorator

@power(n=5)
def get_random_number(from_num: int, to_num: int):
    return random.randint(a=from_num, b=to_num)

print(get_random_number(50, 100))
import functools
from typing import Dict

def mask_data(target_key: str, replace_with: str = "*"):
    """Replace the value of a dictionary with a 'masked' version."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            if isinstance(result, dict) and target_key in result:
                result[target_key] = replace_with * len(str(result[target_key]))
            return result
        return wrapper
    return decorator

@mask_data(target_key="name")
def get_user(name: str, age: int):
    return {
        "name": name,
        "age": age
    }

print(
    get_user(name="Alice", age=30),
    get_user(name="Bob", age=25),
    sep="\n"
)

