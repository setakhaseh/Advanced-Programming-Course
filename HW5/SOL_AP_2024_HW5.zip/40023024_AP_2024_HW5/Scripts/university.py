class University():
    counter = 0

    def __init__(self, name, established, chancellor, faculties=None,filename=None):
        if filename:
            info = []
            with open(filename, 'r') as file:
                for line in file:
                    info.extend(line.split())
            self.name = info[0]
            self.established = info[1]
            self.chancellor = info[2]
        else:
            self.name = name
            self.established = established
            self.chancellor = chancellor
            self.faculties = faculties if faculties is not None else []
        University.counter += 1
        if University.counter > 3:
            raise RuntimeError("Cannot create more than three University instances.")
        

    def __str__(self):
        return f"Here is {self.name}."

    def which_university_is_this(self, student_number):
        for faculty in self.faculties:
            for student in faculty.students:
                if student.student_number == student_number:
                    return self
        return None

    def add_faculties(self, faculties):
        self.faculties.extend(faculties)

class Faculty:
    def __init__(self, name=None, university=None, students=None, professors=None, filename=None):
        if filename:
            info = []
            with open(filename, 'r') as file:
                for line in file:
                    info.extend(line.split())
            self.name = info[0]
            self.established = info[1]
            self.chancellor = info[2]
            self.faculties = info[3]
        else:
            self.name = name
            self.university = university
            self.students = students if students is not None else []
            self.professors = professors if professors is not None else {}

    def add_students(self, students):
        self.students.extend(students)

    def add_professors(self, professors):
        self.professors.update(professors)

    @classmethod
    def get_top_remain(cls, students, degree):
        std_samedeg = []
        for std in students:
            if  std.academic_degree == degree:
                std_samedeg.append(std)
        highest_gpa = 0
        highest_std = None
        for std in std_samedeg:
            if  std.GPA > highest_gpa:
                highest_gpa = std.GPA
                highest_std = std
        return highest_std

    def __add__(self, other):
        self.professors.extend(other.professors)

    def __mod__(self, gpa_threshold):
        op=[]
        for std in self.students:
            if std.GPA> gpa_threshold:
                op.append(std)
        return op

    def __contains__(self, person):
        if person in self.professors or person in self.students:
            return True