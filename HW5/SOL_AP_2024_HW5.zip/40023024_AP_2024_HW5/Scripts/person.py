from datetime import datetime
from university import University, Faculty

class ConstError(Exception):
    pass

class Person:
    def __new__(cls, *args, **kwargs):
        raise TypeError("Cannot instantiate directly")

    def __init__(self, first_name, last_name, birthday, gender):
        self.first_name = first_name
        self.last_name = last_name
        self.__birthday = datetime.strptime(birthday, "%d/%m/%Y")
        self.gender = gender


class Student(Person):
    std_numbers=[]
    def __init__(self, first_name, last_name, birthday, gender, faculty, academic_degree, university, gpa=15):
        Person.__init__(first_name, last_name, birthday, gender)
        if academic_degree != 'Bachelor' or academic_degree!='Master' or academic_degree!='Doctoral':
            raise ValueError
        self.faculty = Faculty(faculty)
        self.academic_degree = academic_degree
        self.university = University(university)
        self.gpa = gpa
        self.__student_number = self._generate_student_number()

    def _generate_student_number(self):
        import random
        while():
            std_num= f"{random.randint(100000, 999999)}"
            if std_num not in Student.std_numbers:
                Student.std_numbers.append(std_num)
                return std_num
            break
    def get_age(self):
        today = datetime.today()
        age = today.year - self.__birthday.year
        if (today.month, today.day) < (self.__birthday.month, self.__birthday.day):
            age -= 1
        return age

    def __str__(self):
        return f"I am {self.first_name} {self.last_name} and studying at {self.university.name}."

class Professor(Person):
    def __init__(self, first_name, last_name, birthday, gender, faculty, academic_rank, university, salary):
        Person.__init__(first_name, last_name, birthday, gender)
        if academic_rank != 'Professor' or academic_rank!='Associate Professor' or academic_rank!='Assistant Professor' or academic_rank!='Lecturer':
            raise ValueError
        self.faculty = faculty
        self.academic_rank = academic_rank
        self.university = university
        self.__salary = salary

    def __str__(self):
        return f"I am {self.academic_rank} {self.first_name} {self.last_name} and studying at {self.university.name}."