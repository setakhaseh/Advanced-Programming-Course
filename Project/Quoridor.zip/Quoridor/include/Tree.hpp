#include "Tree.h"
#include <fstream>
template <typename T>

Tree<T>::Node::Node(T data, std::size_t depth) : data{data}, depth{depth} {
	// std::cout << "a new node is created\n";
}

template <typename T>

Tree<T>::Tree(T roots_data) : root{new Node{roots_data}} {
	leaves.push_back(root);
	// std::cout << "a tree is constructed\n";
}

template <typename T>

Tree<T>::~Tree() {
	std::stack<Node *> stack;
	stack.push(root);
	Node *node;
	while (!stack.empty()) {
		node = stack.top();
		stack.pop();
		for (auto &child : node->_children)
			stack.push(child);

		delete node;
		node = nullptr;
	}
	// std::cout << "tree destructed\n";
}

template <typename T>

void Tree<T>::print_tree(std::optional<std::string> filename) const {
	if (filename.has_value()) {
		std::ofstream File;
		File.open(filename.value());
		File << "\n--------------------------------------------\nprinitng has "
				"started\n--------------------------------------------\n";
		std::queue<Node *> queue;
		queue.push(root);
		Node *node;
		while (!queue.empty()) {
			node = queue.front();
			queue.pop();
			File << "data of node with depth: " << node->depth
				 << "\nand address: " << node
				 << "\nand parent: " << node->parent << "\nis: " << node->data
				 << "\nwith Children:\n";
			File << "----------\n";
			for (auto child : node->_children)
				File << std::endl << child << "\n";
			File << "----------\n";
			for (auto child : node->_children)
				queue.push(child);
		}
		File << "--------------------------------------------\nprinitng is "
				"finished\n--------------------------------------------\n";
		File.close();

	} else {
		std::cout
			<< "\n--------------------------------------------\nprinitng has "
			   "started\n--------------------------------------------\n";
		std::queue<Node *> queue;
		queue.push(root);
		Node *node;
		while (!queue.empty()) {
			node = queue.front();
			queue.pop();
			std::cout << "data of node with depth: " << node->depth
					  << "\nand address: " << node
					  << "\nand parent: " << node->parent
					  << "\nis: " << node->data << "\nwith Children:\n";
			std::cout << "----------\n";
			for (auto child : node->_children)
				std::cout << std::endl << child << "\n";
			std::cout << "----------\n";
			for (auto child : node->_children)
				queue.push(child);
		}
		std::cout
			<< "--------------------------------------------\nprinitng is "
			   "finished\n--------------------------------------------\n";
	}
}

template <typename T>

auto Tree<T>::dfs(std::function<bool(Node *)> filter) {
	std::vector<Node *> results;
	std::stack<Node *> stack;
	stack.push(root);
	Node *node;
	while (!stack.empty()) {
		node = stack.top();
		stack.pop();
		for (auto &child : node->_children)
			stack.push(child);

		if (filter(node))
			results.push_back(node);
	}
	return results;
}

template <typename T>

auto Tree<T>::bfs(std::function<bool(Node *)> filter) {
	std::vector<Node *> results;
	std::queue<Node *> queue;
	queue.push(root);
	Node *node;
	while (!queue.empty()) {
		node = queue.front();
		queue.pop();
		for (auto &child : node->_children)
			queue.push(child);

		if (filter(node))
			results.push_back(node);
	}
	return results;
}

template <typename T>

auto Tree<T>::get_leaves() {
	std::vector<Node *> results;
	std::queue<Node *> queue;
	for (auto leaf : leaves)
		queue.push(leaf);
	Node *node;
	while (!queue.empty()) {
		node = queue.front();
		queue.pop();
		if (node->_children.size() > 0)
			for (auto &child : node->_children)
				queue.push(child);
		else {
			results.push_back(node);
		}
	}
	std::sort(results.begin(), results.end(), [](Node *leaf1, Node *leaf2) {
		if (leaf1->depth < leaf2->depth)
			return true;

		return false;
	});
	leaves = results;
	return leaves;
};
