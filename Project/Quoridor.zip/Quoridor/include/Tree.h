#ifndef TREE_H
#define TREE_H
#include <functional>
#include <initializer_list>
#include <iostream>
#include <queue>
#include <stack>
#include <vector>

template <typename T>

class Tree {
  public:
	class Node {
	  public:
		Node *parent{nullptr};
		std::vector<Node *> _children;
		T data;
		std::size_t depth;
		/*
		@param data represets the data stored in that node
		@param depth(optional) is the depth of that node
		@param is_checked(optional) sets the default value of is_checked to
		false
		%
		makes the node visible for searching algorithms
		*/
		Node(T data, std::size_t depth = 0);
	};
	/*
	@param growing_function algorithm to grow the tree based on
	*/
	Tree(T roots_data = {});
	~Tree();
	/*
	prints the nodes datas stored in the tree
	*/
	void print_tree(std::optional<std::string> filename = std::nullopt) const;
	/*
	implememts the dfs algorithm used to search the tree
	@param filter a function which should return true if the node has to be in
	the resulting filtered search else, false
	*/
	auto dfs(std::function<bool(Node *)> filter);
	/*
	implememts the bfs algorithm used to search the tree
	@param filter a function which should return true if the node has to be in
	the resulting filtered search else, false
	*/
	auto bfs(std::function<bool(Node *)> filter);
	/*
	returns the leaves of the tree in a vector containing addresses of the
	corresponding nodes
	*/
	auto get_leaves();

	auto get_root() { return root; }

  private:
	Node *root;
	std::vector<Node *> leaves;
};

#include "Tree.hpp"

#endif