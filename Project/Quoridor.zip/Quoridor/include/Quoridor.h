#include "Board.h"
#include "Player.h"
#include "Square.h"
#include <chrono>
#include <iostream>
#include <map>
#include <omp.h>
#include <tuple>

#define DEPTH_OF_VIEW 4
#define Tree_Depth 6

class Action {
  public:
	std::string type;
	std::string player_id;
	std::pair<Square_pst, char> put_wall_position;
	Square_pst square_position;
	int value{};
	Action(std::string _type, std::string _player_id)
		: type{_type}, player_id{_player_id} {
		std::cout << "an action created\n";
	}
	Action(std::string _type, std::string _player_id,
		   std::pair<Square_pst, char> _put_wall_position)
		: type{_type}, player_id{_player_id}, put_wall_position{
												  _put_wall_position} {
		// std::cout << "a put wall created\n";
	}

	Action(std::string _type, std::string _player_id,
		   Square_pst _square_position)
		: type{_type}, player_id{_player_id}, square_position{
												  _square_position} {
		// std::cout << "a movePawn created\n";
	}
	friend std::ostream &operator<<(std::ostream &os, const Action &action);
};

std::ostream &operator<<(std::ostream &os, const Action &action) {
	std::string rst{action.player_id + "( " + action.type};
	if (action.type == "MovePawn") {
		// rst += "\tthis is a pawn-move to ";
		rst += "( ";
		rst += std::to_string(action.square_position.first);
		rst += ", ";
		rst += std::to_string(action.square_position.second);
		// rst += "\n";
		rst += " ))";
		os << rst;
	} else if (action.type == "PutWall") {
		// rst += "\tthis is a put-wall in ";
		rst += "{ ";
		rst += std::to_string(action.put_wall_position.first.first);
		rst += ", ";
		rst += std::to_string(action.put_wall_position.first.second);
		rst += " , ";
		rst += action.put_wall_position.second;
		// rst += "\n";
		rst += " })";
		os << rst;
	}
	return os;
}

Board game_board;
Player Master{"", "", {}, 10, ""};
Player Slave{"", "", {}, 10, ""};
std::size_t DEADLINE_IN_MS;
std::map<Tree<Action>::Node *, std::tuple<Board, Player, Player>> status_map;
std::map<std::string, std::size_t> exec_time;
// gameInfo
std::string gameId{};
std::string gameStatus{};
std::string currentTurn{};
// game setting
std::size_t playerCount{};
std::size_t timePerMove{};
std::size_t totalWalls{};
std::size_t boardSize{};
// // players
// Player player1;
// Player player2;
// walls

// turnHistory
std::vector<Action> turnHistory;
auto start_of_growing = std::chrono::high_resolution_clock::now();

/*
takes the new_position of the active_players_view which an exception has occured
on and the current_active_players_position and its board view and checks if the
exception has occured or not
*/
Square_pst Exception1(Square_pst new_position,
					  Square_pst active_players_position,
					  Board active_players_board) {
	for (auto square :
		 active_players_board.get_valid_neighboring_squares(new_position)) {
		if (abs(static_cast<int>(square->get_position().first) -
				active_players_position.first) == 2 ||
			abs(static_cast<int>(square->get_position().second) -
				active_players_position.second) == 2) {
			std::cout << square->get_position().first
					  << square->get_position().second << std::endl;
			std::cout << "Exception 1 has occured\n";
			return square->get_position();
		}
	}
	throw std::invalid_argument{"Exception 1 did not pass"};
}

/*
takes the new_position of the active_players_view which an exception has occured
on and the current_active_players_position and its board view and checks if the
exception has occured or not if so throws a logical error
*/
std::vector<Square_pst> Exception2(Square_pst new_position,
								   Square_pst active_players_position,
								   Board active_players_board) {
	// meaning that the first exception has failed
	std::vector<Square_pst> new_positions;
	for (auto square :
		 active_players_board.get_valid_neighboring_squares(new_position)) {
		if (active_players_position != square->get_position()) {
			// flag = true;
			new_positions.push_back(square->get_position());
		}
	}
	return new_positions;
}

// the board is the actors view of the board
bool is_a_valid_movePawn(Board board, const Player &active,
						 const Player &opponent, Square_pst new_position) {
	if (board.get_square(new_position.first, new_position.second) == nullptr) {
		return false;
	}

	if (new_position == mirror(opponent.get_pawn(), board.get_size())) {
		// Exceptions have occured
		return false;
	}
	for (auto *neighbor :
		 board.get_valid_neighboring_squares(active.get_pawn())) {
		if (neighbor->get_position() == new_position) {
			// active.move_pawn(new_position);
			return true;
		}
	}
	// this means that the new_position is niether a neighbor nor an opponents
	// position so maybey its the right place but we have to check the
	// exceptions first
	// edge cases have not been implemented yet we assum that
	// the opponents position is where you wanted to head to
	try {
		auto except1 = Exception1(mirror(opponent.get_pawn(), board.get_size()),
								  active.get_pawn(), board);
		std::cout << except1.first << ", " << except1.second << std::endl;
		std::cout << (except1 == new_position) << std::endl;
		return except1 == new_position;
	} catch (const std::exception &e) {
		std::cerr << e.what() << '\n';
	}
	try {
		auto except2 = Exception2(mirror(opponent.get_pawn(), board.get_size()),
								  active.get_pawn(), board);
		return std::find(except2.begin(), except2.end(), new_position) !=
			   except2.end();
	} catch (const std::invalid_argument &e) {
		std::cerr << e.what() << '\n';
	}

	return false;
};
bool movePawn(Board &board, Player &active, const Player &opponent,
			  Square_pst new_position) {
	if (is_a_valid_movePawn(board, active, opponent, new_position)) {
		active.move_pawn(new_position);
		return true;
	}
	return false;
}
/*
The board and also the wall and its position should be the active_players view
of the board
*/
bool is_valid_wall_position(Board board, const Player &active_player,
							const Player &opponent,
							std::pair<Square_pst, char> wall) {

	if (!board.put_wall(wall.first, wall.second)) {
		return false;
	}

	try {
		opponent.find_a_way(mirror(board));
	} catch (const std::logic_error &e) {
		return false;
	}
	try {
		active_player.find_a_way(board);
	} catch (const std::logic_error &e) {
		return false;
	}

	return true;
}

bool put_wall(Board &board, Player &active, const Player &opponent,
			  std::pair<Square_pst, char> wall_position) {
	if (is_valid_wall_position(board, active, opponent, wall_position)) {
		board.put_wall(wall_position.first, wall_position.second);
		active.decreament_walls();
		return true;
	}
	return false;
}

bool make_action(Action action, Board &game_board_copy, Player &Master_copy,
				 Player &Slave_copy) {
	if (action.player_id == Master.get_player_id()) {
		if (action.type == "MovePawn") {
			return movePawn(game_board_copy, Master_copy, Slave_copy,
							action.square_position);
		} else if (action.type == "PutWall") {
			// if(!is_valid_wall_position(game_board_copy, Master_copy,
			// action.put_wall_position, Slave_copy))
			return put_wall(game_board_copy, Master_copy, Slave_copy,
							action.put_wall_position);
		}
	} else {
		game_board_copy = mirror(game_board_copy);
		bool result;
		if (action.type == "MovePawn") {
			result = movePawn(game_board_copy, Slave_copy, Master_copy,
							  action.square_position);
			game_board_copy = mirror(game_board_copy);
			return result;

		} else if (action.type == "PutWall") {
			result = put_wall(game_board_copy, Slave_copy, Master_copy,
							  action.put_wall_position);
			game_board_copy = mirror(game_board_copy);
			return result;
		}
		game_board_copy = mirror(game_board_copy);
	}
	return false;
}

std::tuple<Board, Player, Player>
current_status(Tree<Action>::Node *action_node) {
	auto start = std::chrono::high_resolution_clock::now();
	auto end = std::chrono::high_resolution_clock::now();

	auto itr = status_map.find(action_node);
	if (itr == status_map.end()) {
		throw "itreater was not found!";
	}
	end = std::chrono::high_resolution_clock::now();
	exec_time["current_status"] +=
		std::chrono::duration_cast<std::chrono::milliseconds>(end - start)
			.count();
	return (*itr).second;
}

Tree<Action>::Node *add_child(Tree<Action>::Node *leaf, Action childs_data) {
	auto child = new Tree<Action>::Node{childs_data, leaf->depth + 1};
	child->parent = leaf;
	leaf->_children.push_back(child);
	return child;
}

void adding_the_new_state(Tree<Action>::Node *new_born_child, Action action,
						  Player next_active_player, Board next_active_board,
						  Player next_opponent_player,
						  Board next_oppoenent_board) {
	if (next_active_player.get_player_id() == Master.get_player_id()) {
		// copying the previouse state of real board
		make_action(action, next_active_board, next_active_player,
					next_opponent_player); // updating this state

		auto new_state = std::make_tuple(next_active_board, next_active_player,
										 next_opponent_player);
		status_map.insert(
			{new_born_child,
			 new_state}); // adding this new state to the status_map

	} else if (next_active_player.get_player_id() == Slave.get_player_id()) {
		// copying the previouse state of real board
		make_action(action, next_oppoenent_board, next_opponent_player,
					next_active_player); // updating this state
		auto new_state = std::make_tuple(
			next_oppoenent_board, next_opponent_player, next_active_player);
		status_map.insert(
			{new_born_child,
			 new_state}); // adding this new state to the status_map
	}
}

void grow_wall_positions(Tree<Action>::Node *leaf, Player next_active_player,
						 Board next_active_board, Player next_opponent_player,
						 Board next_oppoenent_board) {
	auto walls = next_opponent_player.possible_unique_wall_positions(
		next_oppoenent_board, DEPTH_OF_VIEW);
	for (auto wall : walls) {
		if (next_active_player.get_remaining_walls() < 1) {
			// this player has no remaining walls so, there is no need
			// to add a put wall possibility to the tree
			break;
		}
		auto mirrored_pos = mirror(wall.first, next_oppoenent_board.get_size());

		std::pair<Square_pst, char> mirrored_wall = {
			{mirrored_pos.first - 1, mirrored_pos.second - 1}, wall.second};
		if (!is_valid_wall_position(next_active_board, next_active_player,
									next_opponent_player, mirrored_wall)) {
			// its not a valid wall position
			continue;
		}
		Action action = Action{"PutWall", next_active_player.get_player_id(),
							   mirrored_wall};
		auto new_born_child = add_child(leaf, action);
		///////// adding the new state to the state map is incomplete
		adding_the_new_state(new_born_child, action, next_active_player,
							 next_active_board, next_opponent_player,
							 next_oppoenent_board);
	}
}

void grow_move_pawn(Tree<Action>::Node *leaf, Player next_active_player,
					Board next_active_board, Player next_opponent_player,
					Board next_oppoenent_board) {
	for (auto step : next_active_player.next_unique_steps(next_active_board,
														  false, false)) {
		if (step == mirror(next_opponent_player.get_pawn(),
						   next_oppoenent_board.get_size())) {
			// the next step is on the opponents pawn
			// Exception 1 has occured
			try {
				auto except1 = Exception1(step, next_active_player.get_pawn(),
										  next_active_board);
				Action action = Action{
					"MovePawn", next_active_player.get_player_id(), except1};
				auto new_born_child = add_child(leaf, action);
				adding_the_new_state(new_born_child, action, next_active_player,
									 next_active_board, next_opponent_player,
									 next_oppoenent_board);
				continue;
			} catch (const std::invalid_argument &e) {
				std::cerr << e.what() << '\n';
			}
			try {
				auto except2 = Exception2(step, next_active_player.get_pawn(),
										  next_active_board);
				for (auto new_step : except2) {
					Action action =
						Action{"MovePawn", next_active_player.get_player_id(),
							   new_step};
					auto new_born_child = add_child(leaf, action);
					adding_the_new_state(new_born_child, action,
										 next_active_player, next_active_board,
										 next_opponent_player,
										 next_oppoenent_board);
				}
			} catch (const std::invalid_argument &e) {
				std::cerr << e.what() << '\n';
			}
			continue;
		}
		Action action =
			Action{"MovePawn", next_active_player.get_player_id(), step};
		auto new_born_child = add_child(leaf, action);
		///////// adding the new state to the state map is incomplete
		adding_the_new_state(new_born_child, action, next_active_player,
							 next_active_board, next_opponent_player,
							 next_oppoenent_board);
	}
}

void one_level_deeper(Tree<Action> &tree, std::size_t deadline_in_ms) {
	auto end = std::chrono::high_resolution_clock::now();
	auto start = std::chrono::high_resolution_clock::now();
	for (auto leaf : tree.get_leaves()) {
		auto state = current_status(leaf);

		std::pair<Player, Board> next_active_player_and_board =
			leaf->data.player_id == Master.get_player_id()
				? std::make_pair(std::get<2>(state), mirror(std::get<0>(state)))
				: std::make_pair(std::get<1>(state), std::get<0>(state));

		std::pair<Player, Board> next_opponent_player_and_board =
			leaf->data.player_id == Master.get_player_id()
				? std::make_pair(std::get<1>(state), std::get<0>(state))
				: std::make_pair(std::get<2>(state),
								 mirror(std::get<0>(state)));

		grow_wall_positions(leaf, next_active_player_and_board.first,
							next_active_player_and_board.second,
							next_opponent_player_and_board.first,
							next_opponent_player_and_board.second);
		// growing move pawns
		grow_move_pawn(leaf, next_active_player_and_board.first,
					   next_active_player_and_board.second,
					   next_opponent_player_and_board.first,
					   next_opponent_player_and_board.second);
		// removing the leaves in the status_map that are no longer leaf and
		// have children
		if (auto itr = status_map.find(leaf); itr != status_map.end()) {
			// lets delete the leaf because we no longer need it
			if (!(itr->first->_children.empty()))
				status_map.erase(itr);
		}
		if (end = std::chrono::high_resolution_clock::now();
			std::chrono::duration_cast<std::chrono::milliseconds>(
				end - start_of_growing)
				.count() >= deadline_in_ms) {
			// running out of time
			throw std::logic_error{"running out of time!"};
		}
	}
}

void store(Tree<Action> &tree, std::string filename = "tree.txt") {
	auto start = std::chrono::high_resolution_clock::now();
	auto end = std::chrono::high_resolution_clock::now();
	auto leaves = tree.get_leaves();
	std::ofstream File;
	File.open(filename);
	std::vector<Action> actions;

	for (auto leaf : leaves) {
		auto node = leaf;
		while (node) {
			if (node->parent !=
				nullptr) // if it was not the root node becasue the root
						 // state is the current state of the real board
				actions.push_back(node->data);
			node = node->parent;
		}
		std::reverse(actions.begin(), actions.end());
		File << "( " << leaf->depth << " ) ";
		for (auto action : actions) {
			File << action << ", ";
		}
		File << std::endl;
		actions.erase(actions.begin(), actions.end());
	}
	File << "\n---------------------------------------------------------\n";
	File.close();
	end = std::chrono::high_resolution_clock::now();
	exec_time["store"] +=
		std::chrono::duration_cast<std::chrono::milliseconds>(end - start)
			.count();
}

int predict(Tree<Action> &tree, std::size_t depth, std::size_t deadline_in_ms) {
	auto start = std::chrono::high_resolution_clock::now();
	auto end = std::chrono::high_resolution_clock::now();
	for (std::size_t i{}; i < depth; ++i)
		try {
			one_level_deeper(tree, deadline_in_ms);
		} catch (const std::logic_error &e) {
			std::cerr << e.what() << '\n';
			break;
		}

	std::cout << std::endl;
	end = std::chrono::high_resolution_clock::now();
	exec_time["predict"] +=
		std::chrono::duration_cast<std::chrono::milliseconds>(end - start)
			.count();
	return 0;
}

Action next_optimum_step(Tree<Action> &tree) {
	auto start = std::chrono::high_resolution_clock::now();
	auto end = std::chrono::high_resolution_clock::now();
	auto leaves = tree.get_leaves();
	std::cout << "number of nodes: "
			  << tree.dfs([](auto) { return true; }).size();

	std::cout << "\nnumber of leaves: " << leaves.size() << std::endl;
	////////////////////////////////////////////////////
	// printing to the file
	// assigning a value to the leaves
	std::pair<int, Tree<Action>::Node *> min = {9999, nullptr};

	std::cout << "size of map is: " << status_map.size() << std::endl;
	for (auto leaf : leaves) {
		// std::cout << "getting the current_status";
		auto state = current_status(leaf);
		auto temp_slave_board = mirror(std::get<0>(state));
		auto temp_master_board = std::get<0>(state);
		// std::cout << "giving values to the leaf\n";
		leaf->data.value =
			(std::get<2>(state).count_steps_to_victory(temp_slave_board) -
			 std::get<1>(state).count_steps_to_victory(temp_master_board));
		// std::cout << "value was given to the leaves successfuly\n";
		if (leaf->data.value < min.first) {
			min = std::make_pair(leaf->data.value, leaf);
		}
		// std::cout << "minimum was updated succesfully\n";
	}
	//////////////////////////////////////////////////
	auto node{min.second};
	std::set<Tree<Action>::Node *> bowl;
	for (auto leaf : tree.get_leaves()) {
		bowl.insert(leaf);
	}
	while (!bowl.empty()) {
		std::vector<Tree<Action>::Node *> parents;
		for (auto elemnt : bowl) {
			if (elemnt->parent != nullptr)
				parents.push_back(elemnt->parent);
		}
		bowl.erase(bowl.begin(), bowl.end());
		for (auto parent : parents) {
			if (parent->data.player_id == Master.get_player_id()) {
				// the next players the minimizer so it surely chooses the
				// minimum values among its options
				int min = 9999;
				// finding the minimum value child because its the
				// minimizer
				std::for_each(parent->_children.begin(),
							  parent->_children.end(),
							  [&min](Tree<Action>::Node *child) {
								  if (child->data.value < min) {
									  min = child->data.value;
								  }
							  });
				parent->data.value = min;
			} else if (parent->data.player_id == Slave.get_player_id()) {
				// the next players the maximizer so it surely chooses the
				// maximum values among its options
				int max = -9999;
				// finding the maximum value child
				std::for_each(parent->_children.begin(),
							  parent->_children.end(),
							  [&max](Tree<Action>::Node *child) {
								  if (child->data.value > max) {
									  max = child->data.value;
								  }
							  });
				parent->data.value = max;
			}
		}
		for (auto parent : parents) {
			if (parent != nullptr)
				bowl.insert(parent);
		}
	}
	/////////////////////////////////////////////////////
	auto itr = std::find_if(
		tree.get_root()->_children.begin(), tree.get_root()->_children.end(),
		[&tree](Tree<Action>::Node *child) {
			if (child->data.value == tree.get_root()->data.value) {
				return true;
			} else
				return false;
		});
	std::cout << "your best next move is: " << (*itr)->data
			  << "with value: " << (*itr)->data.value << std::endl;
	end = std::chrono::high_resolution_clock::now();
	exec_time["next_optimum_step"] +=
		std::chrono::duration_cast<std::chrono::milliseconds>(end - start)
			.count();
	return (*itr)->data;
}

// Board game_board;
// Player Master{"", "", {}, 10, ""};
// Player Slave{"", "", {}, 10, ""};
// std::size_t DEADLINE_IN_MS;
// std::map<Tree<Action>::Node *, std::tuple<Board, Player, Player>> status_map;
// std::map<std::string, std::size_t> exec_time;

// // gameInfo
// std::string gameId{};
// std::string gameStatus{};
// std::string currentTurn{};
// // game setting
// std::size_t playerCount{};
// std::size_t timePerMove{};
// std::size_t totalWalls{};
// std::size_t boardSize{};
// // players
// // walls

// // turnHistory
// std::vector<Action> turnHistory;
// auto start_of_growing = std::chrono::high_resolution_clock::now();

int init(std::string _gameId, std::string _gameStatus, std::size_t _playerCount,
		 std::size_t _board_size, std::string Master_id, Square_pst Master_init,
		 std::string Master_type, std::string Master_color,
		 std::string Slave_id, Square_pst Slave_init, std::string Slave_type,
		 std::string Slave_color, std::size_t timePerMove,
		 std::size_t _totalWalls) {
	// initialization of the game
	boardSize = _board_size;
	game_board = Board{{boardSize, boardSize}};
	// computers data
	Master =
		Player{Master_id, Master_type, Master_init, totalWalls, Master_color};

	// Human data
	Slave = Player{Slave_id, Slave_type, Slave_init, totalWalls, Slave_color};
	DEADLINE_IN_MS = /*server deadline*/ timePerMove * 1000 * 0.4;
	gameStatus = _gameStatus;
	gameId = _gameId;
	playerCount = _playerCount;
	totalWalls = _totalWalls;
	std::cout << Master.get_pawn().first << ", " << Master.get_pawn().second
			  << std::endl;

	return 0;
}

Action add_action(Action action) {
	if (!action.type.empty() &&
		!make_action(action, game_board, Master,
					 Slave)) { // if action was not none and it was a valid
							   // action go ahead
		throw std::logic_error{"not a valid action"};
	}
	turnHistory.push_back(action);
	// std::cout << "the action:\n" << action << std::endl;
	// std::cout << "Master data: " << Master.get_pawn().first << ", "
	// 		  << Master.get_pawn().second << std::endl;
	// std::cout << "Slave data: " << Slave.get_pawn().first << ", "
	// 		  << Slave.get_pawn().second << std::endl;

	auto start = std::chrono::high_resolution_clock::now();
	// assuming its computers turn
	Tree<Action> tree{Action{"", Slave.get_player_id()}};
	status_map.insert(
		{tree.get_root(), std::make_tuple(game_board, Master, Slave)});
	// end of initializing the game
	start_of_growing = std::chrono::high_resolution_clock::now();
	predict(tree, Tree_Depth, DEADLINE_IN_MS);
	store(tree);
	auto next_computer_step = next_optimum_step(tree);
	status_map.erase(status_map.begin(), status_map.end());
	// std::cout << "printing timing log\n";
	// for (auto itr : exec_time) {
	// 	std::cout << itr.first << " took: " << itr.second << " ms in total\n";
	// }
	auto end = std::chrono::high_resolution_clock::now();
	std::cout << "total execution time took: "
			  << std::chrono::duration_cast<std::chrono::milliseconds>(end -
																	   start)
					 .count()
			  << std::endl;
	std::cout << "----------------------------------------------------\n";
	std::cout << "your action was: \n" << action << std::endl;
	std::cout << "make action result"
			  << make_action(next_computer_step, game_board, Master, Slave);
	turnHistory.push_back(next_computer_step);
	return next_computer_step;
}

// int main() {
// 	init({9, 9}, "Player2", {0, 4}, "Computer", "black", "Player1", {0, 4},
// 		 "Human", "white", 30);
// 	std::cout << 1 << std::boolalpha
// 			  << make_action(Action{"MovePawn", Master.get_player_id(), {1, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 2
// 			  << make_action(Action{"MovePawn", Slave.get_player_id(), {1, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	std::cout << 3
// 			  << make_action(Action{"MovePawn", Master.get_player_id(), {2, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 4
// 			  << make_action(Action{"MovePawn", Slave.get_player_id(), {2, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 5
// 			  << make_action(Action{"MovePawn", Master.get_player_id(), {3, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 6
// 			  << make_action(
// 					 Action{"PutWall", Slave.get_player_id(), {{0, 4}, 'H'}},
// 					 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	std::cout << 7
// 			  << make_action(
// 					 Action{"PutWall", Master.get_player_id(), {{5, 4}, 'H'}},
// 					 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 8
// 			  << make_action(Action{"MovePawn", Slave.get_player_id(), {2, 5}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 9
// 			  << make_action(Action{"MovePawn", Master.get_player_id(), {4, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << 10
// 			  << make_action(Action{"MovePawn", Slave.get_player_id(), {3, 5}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(Action{"MovePawn", Master.get_player_id(), {5, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {4, 5}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{3, 2}, 'H'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {4, 4}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{3, 4}, 'H'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {4, 3}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{3, 5}, 'V'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {3, 3}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{4, 5}, 'H'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {3, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{4, 7}, 'H'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {3, 3}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{4, 4}, 'V'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {3, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{6, 3}, 'V'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {2, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{7, 5}, 'H'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {2, 1}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(
// 		Action{"PutWall", Master.get_player_id(), {{6, 7}, 'H'}}, game_board,
// 		Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {2, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(Action{"MovePawn", Master.get_player_id(), {5, 3}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {1, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(Action{"MovePawn", Master.get_player_id(), {6, 3}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {1, 1}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(Action{"MovePawn", Master.get_player_id(), {6, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {0, 1}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	/////////////////////////////////////////////
// 	std::cout << make_action(Action{"MovePawn", Master.get_player_id(), {7, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;

// 	std::cout << make_action(Action{"MovePawn", Slave.get_player_id(), {0, 2}},
// 							 game_board, Master, Slave);
// 	std::cout << std::endl;
// 	add_action(Action{"", Slave.get_player_id()});
// }

int main() {
	init({9, 9}, "Player2", "Computer", "black", "Player1", "Human", "white");
	make_action(Action{"PutWall", Master.get_player_id(), {{2, 4}, 'H'}},
				game_board, Master, Slave);
	make_action(Action{"PutWall", Master.get_player_id(), {{3, 3}, 'V'}},
				game_board, Master, Slave);
	make_action(Action{"PutWall", Master.get_player_id(), {{3, 4}, 'V'}},
				game_board, Master, Slave);
	add_action(Action{"", Slave.get_player_id()});
	// while (true) {
	// 	std::string input;
	// 	std::cout << "did it put wall(yes/no)?\n";
	// 	std::cin >> input;
	// 	if (input == "y" || input == "yes" || input == "Y" || input == "YES") {
	// 		// std::cout << "Enter the players id\n";
	// 		// input.erase(input.begin(), input.end());
	// 		// std::cin >> input;
	// 		char direction;
	// 		std::size_t row, col;
	// 		std::cout << "Enter the wall location with respect to the "
	// 					 "player(row, col)\n";
	// 		std::cin >> row;
	// 		std::cin >> col;
	// 		std::cout << "Enter the wall direction with respect to the "
	// 					 "player('H'/'V')\n";
	// 		std::cin >> direction;
	// 		auto aa = add_action(Action{
	// 			"PutWall", Slave.get_player_id(), {{row, col}, direction}});
	// 		std::cout << "do this: " << aa << std::endl;
	// 		input.erase(input.begin(), input.end());
	// 		continue;
	// 	}
	// 	input.erase(input.begin(), input.end());
	// 	std::cout << "did it move pawn(yes/no)?\n";
	// 	std::cin >> input;
	// 	if (input == "y" || input == "yes" || input == "Y" || input == "YES") {
	// 		// std::cout << "Enter the players id\n";
	// 		// input.erase(input.begin(), input.end());
	// 		// std::cin >> input;
	// 		std::size_t row, col;
	// 		std::cout << "Enter the players new location with respect to the "
	// 					 "player(row, col)\n";
	// 		std::cin >> row;
	// 		std::cin >> col;
	// 		auto aa = add_action(
	// 			Action{"MovePawn", Slave.get_player_id(), {row, col}});
	// 		std::cout << "do this: " << aa << std::endl;
	// 		continue;
	// 	}
	// 	auto aa = add_action(Action{"", input});
	// 	std::cout << "do this: " << aa << std::endl;
	// }
}

json::value Game(Action the_action) {
	auto my_action = add_action(the_action);
	json::value result = {{"gameInfo",
						   {{"gameId", gameId},
							{"gameStatus", gameStatus},
							{"currentTurn", Slave.get_player_id()}}},
						  {"setting",
						   {
							   {"playerCount", playerCount},
							   {"timePerMove", timePerMove},
							   {"totalWalls", totalWalls},
							   {"boardSize", boardSize},
						   }},
						  {"players",
						   {
							   {"id", Master.get_player_id()},
							   {"type", Master.get_player_type()},
							   {"position",
								{{"x", Master.get_player_pawn().first},
								 {"y", Master.get_player_pawn().second}}},
							   {"wallsLeft", Master.get_remaining_walls()},
						   }}};
}

using namespace boost::json;

value createGameInfo() {
	object gameInfo;
	gameInfo["gameId"] = "unique_game_identifier";
	gameInfo["gameStatus"] = "ongoing";
	gameInfo["currentTurn"] = "player1";

	return gameInfo;
}

value createSettings() {
	object settings;
	settings["playerCount"] = 2;
	settings["timePerMove"] = 30;
	settings["totalWalls"] = 20;
	settings["boardSize"] = 9;

	return settings;
}

array createPlayers() {
	array players;

	object player1;
	player1["id"] = "player1";
	player1["type"] = "human";
	player1["position"] = {{"x", 4}, {"y", 8}};
	player1["wallsLeft"] = 10;
	player1["color"] = "black";

	object player2;
	player2["id"] = "player2";
	player2["type"] = "human";
	player2["position"] = {{"x", 4}, {"y", 0}};
	player2["wallsLeft"] = 10;
	player2["color"] = "white";

	players.push_back(player1);
	players.push_back(player2);

	return players;
}

object createWalls() {
	object walls;

	array horizontalWalls = {
		{{"start", {{"x", 2}, {"y", 3}}, {"end", {{"x", 3}, {"y", 3}}},
		  {{"start", {{"x", 5}, {"y", 5}}, {"end", {{"x", 6}, {"y", 5}}}}};
}
}
}
;
array verticalWalls = {
	{{"start", {{"x", 3}, {"y", 2}}, {"end", {{"x", 3}, {"y", 3}}},
	  {{"start", {{"x", 5}, {"y", 2}}, {"end", {{"x", 5}, {"y", 3}}}}};
}
}
}
;
walls["horizontal"] = horizontalWalls;
walls["vertical"] = verticalWalls;

return walls;
}

array createTurnHistory() {
	array turnHistory;

	object move1;
	move1["moveCount"] = 1;
	move1["playerId"] = "player1";
	move1["action"] = "move";
	move1["details"] = {
		{"from", {{"x", 4}, {"y", 7}}, {"to", {{"x", 4}, {"y", 8}}};
}
}
;
object move2;
move2["moveCount"] = 2;
move2["playerId"] = "player2";
move2["action"] = "placeWall";
move2["details"] = {
	{"start", {{"x", 3}, {"y", 2}}, {"end", {{"x", 3}, {"y", 3}}};
}
}
turnHistory.push_back(move1);
turnHistory.push_back(move2);

return turnHistory;
}

int main() {
	object gameData;
	gameData["gameInfo"] = createGameInfo();
	gameData["settings"] = createSettings();
	gameData["players"] = createPlayers();
	gameData["walls"] = createWalls();
	gameData["turnHistory"] = createTurnHistory();

	boost::json::ostream os(std::cout);
	os << gameData << std::endl;

	return 0;
}
