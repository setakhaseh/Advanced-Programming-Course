#ifndef PLAYER_H
#define PLAYER_H
#include "Board.h"
#include "Tree.h"
#include "Utils.h"
#include "set"
#include <chrono>
#include <string>

using Square_pst = std::pair<std::size_t, std::size_t>;
class Player {
  private:
	std::string id;
	std::string type;
	Square_pst pawn;
	std::size_t remaining_walls;
	std::string color;

  public:
	Player(std::string _id, std::string _type, Square_pst init_pawn,
		   std::size_t total_walls, std::string init_color)
		: id{_id}, type{_type}, pawn{init_pawn},
		  remaining_walls{total_walls}, color{init_color} {
		// std::cout << "Player with id " << id << " at pawn position "
		// 		  << pawn.first << ", " << pawn.second << std::endl;
	}
	Player &operator=(const Player &otherPLayer) {
		id = otherPLayer.id;
		type = otherPLayer.type;
		pawn = otherPLayer.pawn;
		remaining_walls = otherPLayer.remaining_walls;
		color = otherPLayer.color;
		return *this;
	}
	std::string get_player_id() const { return id; }
	std::string get_player_type() const { return type; }
	std::string get_color() const { return color; }
	/*
	Gets the players pawn position
	*/
	std::pair<std::size_t, std::size_t> get_pawn() const { return pawn; }

	/*
	returns the remaining walls of the player
	*/
	std::size_t get_remaining_walls() const { return remaining_walls; }

	void decreament_walls() {
		if (remaining_walls > 0)
			remaining_walls--;
	}
	/*
	sets the players pawn in the new position
	@param new_position the players pawn new position
	*/
	bool move_pawn(std::pair<std::size_t, std::size_t> new_position) {
		pawn = new_position;
		return true;
	}

	Square_pst find_a_way(const Board &board) const {
		// auto start = std::chrono::high_resolution_clock::now();
		Board copy_board{board};
		copy_board.clear_is_checked();
		auto paths = A_star::find_paths(&copy_board, pawn, true, false);
		// auto end = std::chrono::high_resolution_clock::now();
		// std::cout << "took to find a path: "
		// 		  << std::chrono::duration_cast<std::chrono::microseconds>(
		// 				 end - start)
		// 				 .count()
		// 		  << std::endl;
		return paths.at(0).at(paths.at(0).size() - 1);
	}

	/*
	Returns all the possible next steps that this player can take to move its
	pawn Note: These steps may include positions where the opponents pawn has
	prevoiusly setteled in so, you have to check if the opponenets pawn is not
	there before moving the players pawn
	*/
	std::vector<Square_pst> next_unique_steps(Board &players_board,
											  bool minimal = false,
											  bool print = false) {
		Board copy_board{players_board};
		copy_board.clear_is_checked();
		auto paths = A_star::find_paths(&copy_board, pawn, minimal, print);
		std::vector<Square_pst> all_nonunique_next_steps;
		for (std::size_t i = 0; i < paths.size(); i++) {
			all_nonunique_next_steps.push_back(paths.at(i).at(1));
		}
		std::set<Square_pst> the_set;
		for (auto step : all_nonunique_next_steps)
			the_set.insert(step);

		std::vector<Square_pst> all_unique_next_steps;
		for (auto elemnt : the_set) {
			all_unique_next_steps.push_back(elemnt);
		}

		// should find all the next unique step amongst all the possible
		// paths
		return all_unique_next_steps;
	}

	/*
	Returns all the possible wall positions that this players path can get
	blocked by a wall.
	Note: These wall positions may include positions which are outside of the
	board, meaning they are not a real position of the board.
	*/
	std::vector<std::pair<Square_pst, char>>
	possible_unique_wall_positions(Board &players_board,
								   std::size_t depth_of_view = -1,
								   bool minimal = false) {
		// auto start = std::chrono::high_resolution_clock::now();
		Board copy_board{players_board};
		copy_board.clear_is_checked();
		auto paths = A_star::find_paths(&copy_board, pawn, minimal, false);
		std::vector<std::pair<Square_pst, char>> all_nonunique_walls;
		for (auto &path : paths) {
			for (std::size_t i = 0;
				 i < (depth_of_view > path.size() - 1 ? path.size() - 1
													  : depth_of_view);
				 i++) {
				Square_pst prev_square = path.at(i);
				Square_pst next_square = path.at(i + 1);
				if (prev_square.first != next_square.first) {
					// row of the next square has changed so this is
					// a H wall type can block this part of the path
					std::size_t min_row = prev_square.first < next_square.first
											  ? prev_square.first
											  : next_square.first;
					all_nonunique_walls.push_back(std::make_pair(
						std::make_pair(min_row, prev_square.second), 'H'));
					all_nonunique_walls.push_back(std::make_pair(
						std::make_pair(min_row, prev_square.second - 1), 'H'));
				}
				if (prev_square.second != next_square.second) {
					// col of the next square has changed so this is
					// a V wall type can block this part of the path
					std::size_t min_col =
						prev_square.second < next_square.second
							? prev_square.second
							: next_square.second;
					all_nonunique_walls.push_back(std::make_pair(
						std::make_pair(prev_square.first, min_col), 'V'));
					all_nonunique_walls.push_back(std::make_pair(
						std::make_pair(prev_square.first - 1, min_col), 'V'));
				}
			}
		}
		std::set<std::pair<Square_pst, char>> the_set;
		for (auto step : all_nonunique_walls)
			the_set.insert(step);

		std::vector<std::pair<Square_pst, char>> all_unique_walls;
		for (auto elemnt : the_set) {
			all_unique_walls.push_back(elemnt);
		}
		// auto end = std::chrono::high_resolution_clock::now();
		// static std::size_t total = 0;
		// total +=
		// 	std::chrono::duration_cast<std::chrono::milliseconds>(end - start)
		// 		.count();
		// std::cout << "possible_unique_wall_position took on total: " << total
		// 		  << std::endl;
		return all_unique_walls;
	}
	/*
	This function computes the steps needed to get to the victory
	*/
	std::size_t count_steps_to_victory(Board &board) const {
		Board copy_board{board};
		copy_board.clear_is_checked();
		auto paths = A_star::find_paths(&copy_board, pawn, true, false);
		return paths.at(0).size() - 1;
	}
};

#endif