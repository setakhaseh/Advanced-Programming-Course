#ifndef BOARD_H
#define BOARD_H
#include "Square.h"
#include <fstream>
#include <optional>
#include <set>
#include <string>
class Board {

  private:
	std::vector<std::vector<Square>> squares; // a matrix of squares
	std::set<std::pair<std::pair<size_t, size_t>, char>> walls;

  public:
	Board(std::pair<std::size_t, std::size_t> size = {9, 9});
	/*
	This function returns the Square object in that position
	@param row row index of that Square
	@param colomn column index of that Square
	*/
	Square *get_square(std::size_t row, std::size_t column);
	/*
	This function returns the Square object in that position
	@param row row index of that Square
	@param colomn column index of that Square
	*/
	const Square *get_square(std::size_t row, std::size_t column) const;
	/*
	Returns the size of the board
	*/
	std::pair<std::size_t, std::size_t> get_size() const;
	/*
	Returns all the valid neighbors of the given square(the term valid means no
	wall is between the two squares)
	@param square The given square to search for its neighbors
	*/
	std::vector<Square *>
	get_valid_neighboring_squares(std::pair<std::size_t, std::size_t> position);
	/*
	This function prints the board in a file, if given else in the console
	@param (optional)filename the filename
	*/
	void print_board(std::optional<std::string> filename = std::nullopt) const;
	/*
	Puts a wall in the corresponding position ( if no collision occurs )
	*/
	bool put_wall(std::pair<std::size_t, std::size_t> wall_position,
				  char direction);

	/*
	clears all the is_checked of the squares to false
	*/
	bool clear_is_checked();

	/*
	Returns the walls set of the board
	*/
	std::set<std::pair<std::pair<size_t, size_t>, char>> get_walls() const;
	/*
	Creates a sub Board from the row1 to row2 of the main board
	@param row1 first row of the sub-board
	@param row2 second row of the sub-board
	*/
	Board trim(size_t row1, size_t row2);
};

#endif