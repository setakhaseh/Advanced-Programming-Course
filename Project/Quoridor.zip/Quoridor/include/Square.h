#ifndef SQUARE_H
#define SQUARE_H

#include <iostream>
#include <vector>

class Board; // forward decleration of board class
class Square {
	// lets the board class to access the square private variables
	friend class Board;

  private:
	std::vector<bool> walls;
	/*
	a WallsVector which indicates existance of a wall in  positions <front,
	right, back, left>
	*/
	std::size_t row;
	std::size_t column;
	bool is_checked{};

  public:
	Square(std::size_t row, std::size_t column, std::vector<bool> walls);
	Square(std::size_t row, std::size_t column);
	// Square(const Square &other_square) {}
	explicit Square();
	/*
	This functions returns the walls attribute of this object in a vector with
	format: <front, right, back, left>
	*/
	std::vector<bool> get_walls() const;

	/*
	Returns the position of the square on the board
	*/
	std::pair<std::size_t, std::size_t> get_position() const;

	/*
	Returns the is_checked of the square
	*/
	bool get_is_checked() const { return is_checked; }
	/*
	Makes the is_checked if the Square to true
	*/
	void checked() { is_checked = true; }
	// setter functions
	/*
	This function set a wall in the given index [front, right, back, left]
	@param idx The given index of the position in the above format
	*/
	bool put_wall(const std::size_t idx);
	/*
	This output operator prints the walls of the given square in the format:
	(front, right, back, left)
	*/
	friend std::ostream &operator<<(std::ostream &os, const Square &square);
	/*
	Two Square objects are equal if their position and suurounding walls are
	exactly the same
	*/

	// operator overloading

	bool operator==(const Square &other_square) const;
	bool operator!=(const Square &other_square) const;
};

#endif