#ifndef UTILS_H
#define UTILS_H
// #include "Board.h"
std::pair<size_t, size_t>
mirror(std::pair<size_t, size_t> unmirrored_square_pos,
	   std::pair<size_t, size_t> board_size);

Board mirror(Board &board_active_player);

namespace A_star {

class ShadowSquare {
  public:
	Square *source_square;
	Board *source_board;
	const std::size_t row;
	const std::size_t col;
	ShadowSquare(Square *_square, Board *_board)
		: source_square{_square},
		  source_board{_board}, row{source_square->get_position().first},
		  col{source_square->get_position().second} {};
	std::size_t heuristic() { return source_board->get_size().first - row - 1; }
};

std::vector<Tree<ShadowSquare>::Node *>
fetch_unchecked_leaves(Tree<ShadowSquare> &source_tree) {
	std::vector<Tree<ShadowSquare>::Node *> rst;
	for (auto leaf : source_tree.get_leaves()) {
		if (leaf->data.source_square->get_is_checked() == false) {
			rst.push_back(leaf);
		}
	}
	return rst;
}

std::vector<Tree<ShadowSquare>::Node *>
A_star(std::vector<Tree<ShadowSquare>::Node *> unchecked_leaves) {
	std::vector<std::size_t> h_values(unchecked_leaves.size());
	// calculation for values of every leaf and finding the minimum value
	std::pair<std::size_t, std::size_t> min = {
		9999, 0}; // (<<value>>, <<index of that min>>)
	for (std::size_t i = 0; i < unchecked_leaves.size(); ++i) {
		std::size_t cost = unchecked_leaves.at(i)->depth;
		std::size_t heuristic = unchecked_leaves.at(i)->data.heuristic();
		h_values.at(i) = cost + heuristic;
		if (cost + heuristic < min.first) {
			min = std::make_pair(cost + heuristic, i);
		}
	}
	std::vector<Tree<ShadowSquare>::Node *> rst;
	for (std::size_t i = 0; i < h_values.size(); ++i) {
		if (h_values.at(i) == min.first) {
			rst.push_back(unchecked_leaves.at(i));
		}
	}
	return rst;
}

void grow_optimum(Tree<ShadowSquare>::Node *optimum) {
	std::vector<Square *> ss =
		optimum->data.source_board->get_valid_neighboring_squares(
			{optimum->data.row, optimum->data.col});
	for (std::size_t i = 0; i < ss.size(); i++) {
		if (ss.at(i)->get_is_checked() == false) {
			Tree<ShadowSquare>::Node *child = new Tree<ShadowSquare>::Node{
				ShadowSquare(ss.at(i), optimum->data.source_board),
				optimum->depth + 1};
			child->parent = optimum;
			optimum->_children.push_back(child);
		}
	}
}

std::vector<std::vector<std::pair<std::size_t, std::size_t>>> find_paths(
	Board *board, std::pair<std::size_t, std::size_t> initial_square_position,
	bool minimal_possible_solutions = true, bool print_in_terminal = false) {
	Tree<ShadowSquare> tree{
		ShadowSquare{board->get_square(initial_square_position.first,
									   initial_square_position.second),
					 board}};
	bool flag = false;
	while (true) {
		std::vector<Tree<ShadowSquare>::Node *> unchecked_leaves =
			fetch_unchecked_leaves(tree);
		//////////////////////////////////
		auto leaves = tree.get_leaves();
		if (unchecked_leaves.size() == 0 &&
			std::find_if(leaves.begin(), leaves.end(), [&board](auto *leaf) {
				return leaf->data.row == board->get_size().first - 1;
			}) != tree.get_leaves().end()) {
			throw std::logic_error{"There is no path to the destination"};
		}
		//////////////////////////////////
		std::vector<Tree<ShadowSquare>::Node *> optimum_leaves =
			A_star(unchecked_leaves);
		std::size_t number_of_goal_leaves{};
		for (auto &optimum_leaf : optimum_leaves) {
			if (optimum_leaf->data.row == board->get_size().first - 1) {
				// this leaf is the victory leaf so no need to grow it
				number_of_goal_leaves++;
				// std::cout << "number of goal leaves: " <<
				// number_of_goal_leaves
				// 		  << "\n";
				if (minimal_possible_solutions == true) {
					// we dont have to find all the possible paths so we need to
					// stop
					flag = true;
					break;
				}
				// we have to find all the possible paths so no need to stop
				// with only one victory node
				continue;
			}
			if (minimal_possible_solutions)
				optimum_leaf->data.source_square->checked();
			grow_optimum(optimum_leaf);
			// std::cout << "one optimum node has been added with address:"
			// 		  << optimum_leaf << "\n";
		}
		// std::cout << "stone 2 number_of_goal_leaves:" <<
		// optimum_leaves.size()
		// 		  << " \n";
		if (number_of_goal_leaves == optimum_leaves.size() || flag == true) {
			// all the optimum leaves are victory squares so should stop the
			// search
			break;
		}
	}
	std::vector<Tree<ShadowSquare>::Node *> goal_leaves;
	for (auto leaf : tree.get_leaves()) {
		if (leaf->data.row == board->get_size().first - 1) {
			goal_leaves.push_back(leaf);
		}
	}

	// This finds the full path by traversing the leaves upward to the root
	// and reverse them at the end
	std::vector<std::vector<Tree<ShadowSquare>::Node *>> best_moves;
	for (auto leaf : goal_leaves) {
		Tree<ShadowSquare>::Node *node = leaf;
		std::vector<Tree<ShadowSquare>::Node *> temp;
		while (node) {
			temp.push_back(node);
			node = node->parent;
		}
		std::reverse(temp.begin(), temp.end());
		best_moves.push_back(temp);
	}
	////////////////////////////////////////////////////////////////////////////

	// This prints the possible paths in the terminal if told so
	if (print_in_terminal) {
		for (auto pawn_moves : best_moves) {
			std::cout << "one possible movement is------\n";
			for (auto move : pawn_moves) {
				std::cout << *move->data.source_square;
			}
			std::cout << "end of this movement------\n";
		}
		std::cout << "There are " << best_moves.size()
				  << " number of optimal solutions\n";
		std::cout
			<< "Total Number of nodes: "
			<< tree.dfs([](Tree<ShadowSquare>::Node *) { return true; }).size()
			<< std::endl;
	}
	//////////////////////////////////////////////////////////////

	// This returns the ShadowSquare of paths
	std::vector<std::vector<std::pair<std::size_t, std::size_t>>> result(
		best_moves.size());
	for (std::size_t i{}; i < best_moves.size(); ++i) {
		auto pawn_moves = best_moves.at(i);
		for (std::size_t j{}; j < pawn_moves.size(); ++j) {
			auto move = pawn_moves.at(j);
			result.at(i).push_back(
				std::make_pair(move->data.row, move->data.col));
		}
	}
	board->clear_is_checked();
	return result;
}

} // namespace A_star

#endif