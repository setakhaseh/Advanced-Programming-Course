#include "Quoridor.h"
#include <boost/asio.hpp>
#include <boost/json.hpp>
#include <iostream>

using boost::asio::ip::tcp;
namespace json = boost::json;

std::string dummy_function() {
	std::string Game()
		json::value result = {{"status", "completed"}, {"count", 10000}};
	return json::serialize(result);
}

void handle_connection(tcp::socket &socket) {
	try {
		boost::asio::streambuf buffer;
		boost::system::error_code error;

		// Read data until newline
		boost::asio::read_until(socket, buffer, "\n", error);

		if (error && error != boost::asio::error::eof) {
			throw boost::system::system_error(error);
		}

		std::istream stream(&buffer);
		std::string received_data((std::istreambuf_iterator<char>(stream)),
								  std::istreambuf_iterator<char>());
		std::cout << "Received JSON: " << received_data << std::endl;

		// Parse the JSON
		json::value parsed_data = json::parse(received_data);
		Player player1(parsed_data["players"][0]["id"],
					   parsed_data["players"][0]["type"],
					   Square_pst(parsed_data["players"][0]["position"]["x"],
								  parsed_data["players"][0]["position"]["y"]),
					   parsed_data["players"][0]["wallsLeft"],
					   parsed_data["players"][0]["color"]);

		Player player2(parsed_data["players"][1]["id"],
					   parsed_data["players"][1]["type"],
					   Square_pst(parsed_data["players"][1]["position"]["x"],
								  parsed_data["players"][1]["position"]["y"]),
					   parsed_data["players"][1]["wallsLeft"],
					   parsed_data["players"][1]["color"]);
		// Create the Board
		size_t boardSize = parsed_data["settings"]["boardSize"];
		Board board(boardSize);

		// Add walls to the board
		for (const auto &wall : parsed_data["walls"]) {
			board.addWall(wall["x"], wall["y"], wall["orientation"]);
		}

		// Perform dummy function and send response
		std::string response = dummy_function();
		boost::asio::write(socket, boost::asio::buffer(response + "\n"), error);

		if (error) {
			throw boost::system::system_error(error);
		}

		std::cout << "Sent JSON: " << response << std::endl;

	} catch (std::exception &e) {
		std::cerr << "Exception in thread: " << e.what() << "\n";
	}
}

int main() {
	try {
		boost::asio::io_service io_service;
		tcp::acceptor acceptor(io_service, tcp::endpoint(tcp::v4(), 12345));

		std::cout << "Server listening on port 12345" << std::endl;

		while (true) {
			tcp::socket socket(io_service);
			acceptor.accept(socket);
			handle_connection(socket);
		}
	} catch (std::exception &e) {
		std::cerr << "Exception: " << e.what() << "\n";
	}

	return 0;
}
