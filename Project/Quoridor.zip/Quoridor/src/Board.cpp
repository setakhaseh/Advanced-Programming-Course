#include "Board.h"
Board::Board(std::pair<std::size_t, std::size_t> size) {
	for (std::size_t i{}; i < size.first; ++i) {
		std::vector<Square> temp;
		for (std::size_t j{}; j < size.second; ++j) {
			temp.push_back(Square{i, j});
		}
		squares.push_back(temp);
	}
	// std::cout << "A board is created..." << std::endl;
}

bool is_inside_board(std::size_t row, std::size_t column, const Board &board) {
	if (row >= board.get_size().first || column >= board.get_size().second)
		return false;
	return true;
}

Square *Board::get_square(std::size_t row, std::size_t column) {
	if (!is_inside_board(row, column, (*this)))
		return nullptr;
	return &(squares.at(row).at(column));
}

const Square *Board::get_square(std::size_t row, std::size_t column) const {
	if (!is_inside_board(row, column, (*this)))
		return nullptr;
	return &(squares.at(row).at(column));
}

std::pair<std::size_t, std::size_t> Board::get_size() const {
	return {squares.size(), squares.at(0).size()};
}

std::vector<Square *> Board::get_valid_neighboring_squares(
	const std::pair<std::size_t, std::size_t> position) {
	Square *center_square{get_square(position.first, position.second)};
	// the case where this happens will never occur
	if (center_square == nullptr)
		throw std::invalid_argument{"Board::get_valid_neighboring_squares -> "
									"The given position is invalid!"};
	std::vector<Square *> rst;
	if (Square * front{get_square(position.first + 1, position.second)};
		front != nullptr && center_square->get_walls().at(0) == false)

		rst.push_back(front);
	if (Square * right{get_square(position.first, position.second + 1)};
		right != nullptr && center_square->get_walls().at(1) == false)
		rst.push_back(right);
	if (Square * back{get_square(position.first - 1, position.second)};
		back != nullptr && center_square->get_walls().at(2) == false)
		rst.push_back(back);
	if (Square * left{get_square(position.first, position.second - 1)};
		left != nullptr && center_square->get_walls().at(3) == false)
		rst.push_back(left);
	return rst;
}

void Board::print_board(std::optional<std::string> filename) const {
	if (filename.has_value()) {
		std::ofstream File{filename.value()};
		for (std::size_t i{}; i < squares.size(); ++i) {
			for (std::size_t j{}; j < squares.at(i).size(); ++j) {
				File << squares.at(i).at(j);
			}
			File << std::endl;
		}
	} else {
		for (std::size_t i{}; i < squares.size(); ++i) {
			for (std::size_t j{}; j < squares.at(i).size(); ++j) {
				std::cout << squares.at(i).at(j);
			}
			std::cout << std::endl;
		}
	}
}

bool Board::put_wall(std::pair<std::size_t, std::size_t> wall_position,
					 char direction) {
	if ((wall_position.first >= get_size().first - 1) ||
		(wall_position.second >= get_size().second - 1)) {
		return false;
	} // These are the critical areas => ( the
	// last row and last column)
	if (walls.find({wall_position, direction}) != walls.end() &&
		!walls.empty()) // the wall position is clear and we can put wall
	{
		// std::cout << "this is not a new wall:\n";
		// std::cout << "putting wall : " << wall_position.first << ", "
		// 		  << wall_position.second << " type: " << direction
		// 		  << std::endl;
		return false;
	}
	// std::cout << "putting wall : " << wall_position.first << ", "
	// 		  << wall_position.second << " type: " << direction << std::endl;
	if (direction == 'H') {
		// checking for horizoental collision
		if (walls.find({{wall_position.first, wall_position.second - 1},
						direction}) != walls.end() &&
			!walls.empty()) {
			return false;
		}
		if (walls.find({{wall_position.first, wall_position.second + 1},
						direction}) != walls.end() &&
			!walls.empty()) {
			return false;
		}
		// checking for vertical collision
		if (walls.find({{wall_position.first, wall_position.second}, 'V'}) !=
				walls.end() &&
			!walls.empty()) {
			return false;
		}
		get_square(wall_position.first, wall_position.second)->put_wall(0);
		get_square(wall_position.first, wall_position.second + 1)->put_wall(0);
		get_square(wall_position.first + 1, wall_position.second)->put_wall(2);
		get_square(wall_position.first + 1, wall_position.second + 1)
			->put_wall(2);
		walls.insert({wall_position, direction});
		return true;
	}
	if (direction == 'V') {
		// checking for vertical collision
		if (walls.find({{wall_position.first - 1, wall_position.second},
						direction}) != walls.end() &&
			!walls.empty()) {
			return false;
		}
		if (walls.find({{wall_position.first + 1, wall_position.second},
						direction}) != walls.end() &&
			!walls.empty()) {
			return false;
		}
		// checking for horizontal collision
		if (walls.find({{wall_position.first, wall_position.second}, 'H'}) !=
				walls.end() &&
			!walls.empty()) {
			return false;
		}
		get_square(wall_position.first, wall_position.second)->put_wall(1);
		get_square(wall_position.first + 1, wall_position.second)->put_wall(1);
		get_square(wall_position.first, wall_position.second + 1)->put_wall(3);
		get_square(wall_position.first + 1, wall_position.second + 1)
			->put_wall(3);
		walls.insert({wall_position, direction});
		return true;
	}
	return false;
}

bool Board::clear_is_checked() {
	for (std::size_t i{}; i < squares.size(); ++i) {
		for (std::size_t j{}; j < squares.at(i).size(); ++j) {
			squares.at(i).at(j).is_checked = false;
		}
	}
	return true;
}

std::set<std::pair<std::pair<size_t, size_t>, char>> Board::get_walls() const {
	return walls;
}

Board Board::trim(size_t row1, size_t row2) {
	Board trimmed{{row2 - row1 + 1, get_size().second}};
	for (auto wall : walls) {
		if (wall.first.first >= row1 && wall.first.first < row2) {
			trimmed.put_wall(wall.first, wall.second);
		}
	}
	return trimmed;
}