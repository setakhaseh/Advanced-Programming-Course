const net = require("net");

const sendJson = () => {
  const client = new net.Socket();
  const jsonData = JSON.stringify({
    gameInfo: {
      gameId: "unique_game_identifier",
      gameStatus: "ongoing",
      currentTurn: "player1",
    },
    settings: {
      playerCount: 2,
      timePerMove: 30,
      totalWalls: 20,
      boardSize: 9,
    },
    players: [
      {
        id: "player1",
        type: "human",
        position: { x: 4, y: 8 },
        wallsLeft: 10,
        color: "black",
      },
      {
        id: "player2",
        type: "human",
        position: { x: 4, y: 0 },
        wallsLeft: 10,
        color: "white",
      },
    ],
    walls: {
      horizontal: [
        { start: { x: 2, y: 3 }, end: { x: 3, y: 3 } },
        { start: { x: 5, y: 5 }, end: { x: 6, y: 5 } },
      ],
      vertical: [
        { start: { x: 3, y: 2 }, end: { x: 3, y: 3 } },
        { start: { x: 5, y: 2 }, end: { x: 5, y: 3 } },
      ],
    },
    turnHistory: [
      {
        moveCount: 1,
        playerId: "player1",
        action: "move",
        details: { from: { x: 4, y: 7 }, to: { x: 4, y: 8 } },
      },
      {
        moveCount: 2,
        playerId: "player2",
        action: "placeWall",
        details: { start: { x: 3, y: 2 }, end: { x: 3, y: 3 } },
      },
    ],
  });

  client.connect(12345, "127.0.0.1", () => {
    console.log("Connected to server");
    client.write(jsonData + "\n");
  });

  client.on("data", (data) => {
    console.log("Received from server: " + data.toString());
    client.destroy(); // Ensure the connection is closed after receiving the data
  });

  client.on("error", (err) => {
    console.error("Connection error:", err.message);
  });

  client.on("close", () => {
    console.log("Connection closed");
  });
};

// Send JSON every 30 seconds
setInterval(sendJson, 30000);
