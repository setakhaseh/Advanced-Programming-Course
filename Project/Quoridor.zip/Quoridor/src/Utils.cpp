#include "Board.h"
#include <chrono>
std::pair<size_t, size_t>
mirror(std::pair<size_t, size_t> unmirrored_square_pos,
	   std::pair<size_t, size_t> board_size) {
	return std::make_pair(board_size.first - unmirrored_square_pos.first - 1,
						  board_size.second - unmirrored_square_pos.second - 1);
}

Board mirror(Board &board_active_player) {
	// auto start = std::chrono::high_resolution_clock::now();
	// static double total = 0;
	Board copy_board{board_active_player.get_size()};
	// std::cout << "mirroring the board\n";
	for (auto wall : board_active_player.get_walls()) {
		auto mirrored_pos = mirror(wall.first, copy_board.get_size());
		copy_board.put_wall({mirrored_pos.first - 1, mirrored_pos.second - 1},
							wall.second);
	}
	// copy_board.print_board();
	// auto end = std::chrono::high_resolution_clock::now();
	// total += std::chrono::duration_cast<std::chrono::microseconds>(end -
	// start) 			 .count() / 		 1000; std::cout << "mirroring took(microsec): " <<
	// total << std::endl;
	return copy_board;
}
