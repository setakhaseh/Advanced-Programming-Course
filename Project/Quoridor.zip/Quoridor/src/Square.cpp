#include "Square.h"

Square::Square() : Square{0, 0, {false, false, false, false}} {};

Square::Square(std::size_t row, std::size_t column, std::vector<bool> walls)
	: walls{walls}, row{row}, column{column} {}

Square::Square(std::size_t row, std::size_t column)
	: Square{row, column, {false, false, false, false}} {}

std::vector<bool> Square::get_walls() const { return walls; }

std::pair<std::size_t, std::size_t> Square::get_position() const {
	return std::make_pair(row, column);
}

bool Square::put_wall(const std::size_t index) {
	if (index > 3)
		return false;
	walls.at(index) = true;
	return true;
}

std::ostream &operator<<(std::ostream &os, const Square &square) {
	os << std::boolalpha;
	os << "Square (" << square.row << ", " << square.column << "), "
	   << " walls: [ ";
	for (std::size_t i{}; i < square.walls.size(); ++i)
		os << square.walls.at(i) << " ";
	os << "]" << std::endl;
	os << std::noboolalpha;
	return os;
}

bool Square::operator==(const Square &other_square) const {
	if (row == other_square.row && column == other_square.column &&
		get_walls() == other_square.get_walls())
		return true;
	else
		return false;
}

bool Square::operator!=(const Square &other_square) const {
	return (*this) == other_square ? false : true;
}