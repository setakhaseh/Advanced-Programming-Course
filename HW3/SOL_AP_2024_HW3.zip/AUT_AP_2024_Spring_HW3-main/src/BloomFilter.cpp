#include "BloomFilter.h"

#include <fstream>
#include <iostream>

#include "CDNServer.h"
template <std::size_t N>
BloomFilter<N>::BloomFilter(unsigned int num_hashes)
    : num_hashes(num_hashes), server(new CDNServer) {}
template <std::size_t N>
BloomFilter<N>::BloomFilter(const BloomFilter& other) {
  num_hashes = other.num_hashes;
  server = other.server;
}
template <std::size_t N>
BloomFilter<N>::BloomFilter(BloomFilter&& other) noexcept
    : num_hashes{other.num_hashes}, server{other.server} {
  num_hashes = nullptr;
  server = nullptr;
}
template <std::size_t N>
BloomFilter<N>::~BloomFilter() {}
template <std::size_t N>
void BloomFilter<N>::add(const std::string& item) {
  std::string word{item};
  server->addWord(word);
  for (std::size_t i = 0; i < num_hashes; ++i) {
    std::size_t index = hash(word, seeds[i]) % N;
    bits.set(index);
  }
}
template <std::size_t N>
void BloomFilter<N>::add(std::string&& file_name) {
  std::vector<std::string> items;
  std::ifstream file(file_name);
  if (!file) {
    std::cout << "Unable to open file";
  }
  char ch;
  char comma{","};
  std::size_t i{};
  while (file.get(ch)) {
    if (ch != comma)  // seperating the words
      items[i] + ch;
    else {
      file.get(ch);  // for the space after comma
      i++;
    }
  }
  file.close();
  for (std::size_t j{}; j < i; j++) add(items[j]);
}
template <std::size_t N>
bool BloomFilter<N>::possiblyContains(const std::string& item) const {
  for (std::size_t i{}; i < num_hashes; ++i) {
    std::size_t index = hash(item, seeds[i]) % N;
    if (!bits.test(index)) {
      return false;
    }
  }
  return true;
}
template <std::size_t N>
bool BloomFilter<N>::possiblyContains(std::string&& item) const {
  for (std::size_t i{}; i < num_hashes; ++i) {
    std::size_t index = hash(item, seeds[i]) % N;
    if (!bits.test(index)) {
      return false;
    }
  }
  return true;
}
template <std::size_t N>
bool BloomFilter<N>::certainlyContains(const std::string& item) const {
  if (possiblyContains(item)) {
    return server->checkWord(item);
  }
  return false;
}
template <std::size_t N>
bool BloomFilter<N>::certainlyContains(std::string&& item) const {
  if (possiblyContains(item)) {
    return server->checkWord(item);
  }
  return false;
}
template <std::size_t N>
void BloomFilter<N>::reset() {
  delete bits;
  server->usage_count = 0;
  delete server->words;
}
template <std::size_t N>
BloomFilter<N>& BloomFilter<N>::operator&(const BloomFilter& other) {
  BloomFilter<N> intersection(other.num_hashes);
  for (std::size_t i{}; i < N; ++i) {
    intersection.bits(i) = bits(i) && other.bits(i);
  }
  return intersection;
}
template <std::size_t N>
BloomFilter<N>& BloomFilter<N>::operator|(const BloomFilter& other) {
  BloomFilter<N> Uni(other.num_hashes);
  Uni = BloomFilter<N>(other);
  for (std::size_t i{}; i < N; ++i) {
    Uni.bits(i) = bits(i) || other.bits(i);
  }
}
template <std::size_t N>
bool BloomFilter<N>::operator()(const std::string& item) const {
  return possiblyContains(item);
}
template <std::size_t M>
std::ostream& operator<<(std::ostream& os, const BloomFilter<M>& bloom_filter) {
  os << "Bloom Filter Words:" << std::endl;
  for (std::size_t i{}; i < bloom_filter.server->words.size(); ++i) {
    os << "Number of Hashes: " << bloom_filter.server->words[i] << std::endl;
  }

  return os;
}
template <std::size_t M>
std::istream& operator>>(std::istream& is, BloomFilter<M>& bloom_filter) {
  for (std::size_t i{}; i < bloom_filter.server->words.size(); ++i) {
    is >> bloom_filter.server->words[i];
  }

  return is;
}
