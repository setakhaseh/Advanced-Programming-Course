#include "Trie.h"

#include <iostream>
#include <queue>
#include <stack>

// Node implementation
Trie::Node::Node(char data, bool is_finished)
    : parent(nullptr), data(data), is_finished(is_finished) {
  children.fill(nullptr);
}

Trie::Node::~Node() {
  for (auto child : children) {
    delete child;
  }
}

// Trie implementation
Trie::Trie() : root(new Node()) { root = nullptr; }
Trie::Trie(const Trie& other) {
  root = new Node();
  *root = *(other.root);
}

Trie::Trie(Trie&& other) : root{other.root} { other.root = nullptr; }
Trie::Trie(std::initializer_list<std::string> list) : Trie() {
  for (const std::string& word : list) {
    insert(word);
  }
}

Trie::~Trie() { delete root; }
Trie& Trie::operator=(const Trie& other) {
  if (this != &other) {
    delete root;
    root = new Node();
    *root = *(other.root);
  }
  return *this;
}
Trie& Trie::operator=(Trie&& other) {
  root = other.root;
  root = nullptr;
  return *this;
}
void Trie::insert(const std::string& str) {
  std::string strp{str};
  Node* temproot = root;
  Node* temproot2;
  for (std::size_t i{}; i < strp.size(); i++) {
    strp[i] = tolower(str[i]);
  }
  if (root->children[(int)strp[0] - 97] != NULL)
    temproot = new Node(strp[0], false);
  else
    temproot = root->children[(int)strp[0] - 97];

  for (std::size_t i{1}; i < strp.size() - 1; i++) {
    if (temproot->children[(int)strp[i] - 97] != NULL) {
      temproot2 = new Node(strp[i], false);
      temproot2->parent = temproot;
      temproot->children[(int)strp[i] - 97] = temproot2;
    } else
      temproot2 = temproot->children[(int)strp[i] - 97];
    temproot2 = temproot;
  }
  if (temproot->children[(int)strp[strp.size()] - 97] != NULL) {
    temproot2 = new Node(strp[strp.size()], true);
    temproot2->parent = temproot;
    temproot->children[(int)strp[strp.size()] - 97] = temproot2;
  } else
    temproot2 = temproot->children[(int)strp[strp.size()] - 97];
  temproot = temproot2;
}
bool Trie::search(const std::string& query) const {
  std::string strp{query};
  Node* temproot = root;
  Node* temproot2;
  for (std::size_t i{}; i < strp.size(); i++) {
    strp[i] = tolower(query[i]);
  }
  for (std::size_t i{0}; i < strp.size(); i++) {
    if (temproot->children[(int)strp[i] - 97] != NULL) {
      return false;
    } else
      temproot2 = temproot->children[(int)strp[i] - 97];
    temproot = temproot2;
  }
  if (temproot->is_finished)
    return true;
  else
    return false;
}
bool Trie::startsWith(const std::string& prefix) const {
  std::string strp{prefix};
  Node* temproot = root;
  Node* temproot2;
  for (std::size_t i{}; i < strp.size(); i++) {
    strp[i] = tolower(prefix[i]);
  }
  for (std::size_t i{0}; i < strp.size(); i++) {
    if (temproot->children[(int)strp[i] - 97] != NULL) {
      return false;
    } else
      temproot2 = temproot->children[(int)strp[i] - 97];
    temproot = temproot2;
  }
  return true;
}
void Trie::remove(const std::string& str) {
  std::string strp{str};
  Node* temproot = root;
  Node* temproot2;

  if (search(str))
    std::cout << "No such a word exists in this trie" << std::endl;
  else {
    for (std::size_t i{}; i < strp.size(); i++) {
      temproot2 = temproot->children[(int)strp[i] - 97];
      temproot = temproot2;
    }
    int haschild{};
    // last alphabet
    for (std::size_t j{}; j < 26; j++)
      if (temproot->children[j] != NULL) haschild = 1;
    if (haschild == 1)
      temproot->is_finished = false;
    else {
      temproot2 = temproot;
      delete temproot2;
      temproot = temproot->parent;
      for (std::size_t i{strp.size() - 1}; i > 0; i++) {
        for (std::size_t j{}; j < 26; j++)
          if (temproot->children[j] != NULL) haschild = 1;
        if (haschild == 1)
          break;
        else if (!(temproot->is_finished)) {
          temproot2 = temproot;
          delete temproot2;
          temproot = temproot->parent;
        }
      }
    }
  }
}
void Trie::bfs(std::function<void(Node*&)> func) {
  if (root == nullptr) {
    return;
  }

  std::queue<Node*> nodeQueue;
  nodeQueue.push(root);

  while (!nodeQueue.empty()) {
    Node* current = nodeQueue.front();
    nodeQueue.pop();

    func(current);

    for (Node* child : current->children) {
      if (child != nullptr) {
        nodeQueue.push(child);
      }
    }
  }
}
void Trie::dfs(std::function<void(Node*&)> func) {
  if (root == nullptr) {
    return;
  }

  std::stack<Node*> nodeStack;
  nodeStack.push(root);

  while (!nodeStack.empty()) {
    Node* current = nodeStack.top();
    nodeStack.pop();

    func(current);

    for (Node* child : current->children) {
      if (child != nullptr) {
        nodeStack.push(child);
      }
    }
  }
}
std::ostream& operator<<(std::ostream& os, const Trie& trie) {
  std::function<void(Trie::Node*)> dfsPrint = [&](Trie::Node* node) {
    if (node == nullptr) {
      return;
    }

    os << node->data;
    if (node->is_finished) {
      os << ", ";
    }

    for (Trie::Node* child : node->children) {
      dfsPrint(child);
    }
  };
  dfsPrint(trie.root);

  return os;
}
std::istream& operator>>(std::istream& is, Trie& trie) {
  std::string word;
  while (is >> word) {
    trie.insert(word);
  }
  return is;
}
Trie Trie::operator+(const Trie& other) const {
  Trie result(*this);
  std::function<void(Trie::Node*, std::string)> insertWords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          result.insert(prefix +
                        node->data);  // Insert the word into the result Trie
        }

        for (int i = 0; i < 26; ++i) {
          insertWords(node->children[i], prefix + node->data);
        }
      };

  // Insert words from the current Trie into the result Trie
  insertWords(root, "");

  // Insert words from the 'other' Trie into the result Trie
  insertWords(other.root, "");

  return result;
}
Trie& Trie::operator+=(const Trie& other) {
  std::function<void(Trie::Node*, std::string)> insertWords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          insert(prefix + node->data);  // Insert the word into the result Trie
        }

        for (int i = 0; i < 26; ++i) {
          insertWords(node->children[i], prefix + node->data);
        }
      };

  // Insert words from the current Trie into the result Trie
  insertWords(root, "");

  // Insert words from the 'other' Trie into the result Trie
  insertWords(other.root, "");

  return *this;
}
Trie Trie::operator-(const Trie& other) const {
  Trie result(*this);
  std::function<void(Trie::Node*, std::string)> insertWords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          result.insert(prefix +
                        node->data);  // Insert the word into the result Trie
        }

        for (int i = 0; i < 26; ++i) {
          insertWords(node->children[i], prefix + node->data);
        }
      };
  insertWords(root, "");
  std::function<void(Trie::Node*, std::string)> removewords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          if (search(prefix + node->data)) result.remove(prefix + node->data);
        }

        for (int i = 0; i < 26; ++i) {
          removewords(node->children[i], prefix + node->data);
        }
      };
  removewords(other.root, "");
  return result;
}
Trie& Trie::operator-=(const Trie& other) {
  std::function<void(Trie::Node*, std::string)> removewords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          if (search(prefix + node->data)) remove(prefix + node->data);
        }

        for (int i = 0; i < 26; ++i) {
          removewords(node->children[i], prefix + node->data);
        }
      };
  removewords(other.root, "");
  return *this;
}
bool Trie::operator()(const std::string& query) const { return search(query); }
bool Trie::operator==(const Trie& other) const {
  Trie result(*this);
  std::function<void(Trie::Node*, std::string)> insertWords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          result.insert(prefix +
                        node->data);  // Insert the word into the result Trie
        }

        for (int i = 0; i < 26; ++i) {
          insertWords(node->children[i], prefix + node->data);
        }
      };
  insertWords(root, "");
  std::function<void(Trie::Node*, std::string)> removewords =
      [&](Trie::Node* node, std::string prefix) {
        if (node == nullptr) {
          return;
        }

        if (node->is_finished) {
          if (search(prefix + node->data)) result.remove(prefix + node->data);
        }

        for (int i = 0; i < 26; ++i) {
          removewords(node->children[i], prefix + node->data);
        }
      };
  removewords(other.root, "");
  for (std::size_t i{}; i < 26; i++)
    if (result.root->children[i] != NULL) return false;
  return true;
}
bool Trie::operator!=(const Trie& other) const { return !(this == &other); }