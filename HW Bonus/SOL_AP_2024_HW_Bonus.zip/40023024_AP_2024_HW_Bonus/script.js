"use strict";

// Function to reset the game
function newGame() {
    document.body.style.backgroundColor = '#69cbc0';//to return the color to the privious state (after a full game)
    btnRoll.style.pointerEvents = 'auto';
    btnHold.style.pointerEvents = 'auto';
    activePlayer = player_0;
    activatePlayer(player_0);
    player_0_score.textContent = 0;
    player_1_score.textContent = 0;
    dice_image.classList.add("hidden");
    Game_state = true;
    // Initialize the variables to 0
    currentScore = 0; 
    scores = [0, 0];
    current_0.textContent = 0;
    current_1.textContent = 0;
}

// Function to activate player
function activatePlayer(activePlayer) {
    if (activePlayer === player_0) {
        player_1.classList.remove("active-player");
        player_0.classList.add("active-player");
    } else {
        player_0.classList.remove("active-player");
        player_1.classList.add("active-player");
    }
}

// Function to set the dice image
function setDiceImage(imageNumber) {
    dice_image.classList.remove("hidden");
    dice_image.src = `./dice-${imageNumber}.png`;
}

// Function to generate a random dice number
function generateDiceNumber() {
    return Math.ceil(Math.random() * 6);
}

// Function to set the current score based on the active player
function setcurrentScore() {
    if (activePlayer === player_0) {
        current_0.textContent = currentScore;
    } else {
        current_1.textContent = currentScore;
    }
}

// Function to set the collected score based on the active player after hold
function setScore() {
    if (activePlayer == player_0) {
        scores[0] += currentScore;
        player_0_score.textContent = scores[0];
    } else {
        scores[1] += currentScore;
        player_1_score.textContent = scores[1];
    }
    //check if the game has ended or not
    if (scores[0] >= 100) {
        winnerAnnouncement(player_0);
    } else if (scores[1] >= 100) {
        winnerAnnouncement(player_1);
    } else {
        switchPlayer();
    }
}

// Function to switch the player
function switchPlayer() {
    currentScore = 0;
    if (activePlayer === player_1) {
        current_1.textContent = 0;
        activePlayer = player_0;
        activatePlayer(player_0);
    } else {
        current_0.textContent = 0;
        activePlayer = player_1;
        activatePlayer(player_1);
    }
}
//Function to end the game and declare the winner
function winnerAnnouncement(player) {
    document.body.style.backgroundColor = '#E64980';
    btnRoll.style.pointerEvents = 'none';
    btnHold.style.pointerEvents = 'none';
    Game_state = false;

    if (player == player_0) {
        current_0.textContent = '🎉';
    } else {
        current_1.textContent = '🎉';
    }
}

// DOM elements and initializations
let player_0_score = document.getElementById("player-0-score");
let player_1_score = document.getElementById("player-1-score");
const dice_image = document.querySelector(".dice-image");
const player_0 = document.querySelector(".player-0");
const player_1 = document.querySelector(".player-1");
const current_0 = document.getElementById("player-0-current-amount");
const current_1 = document.getElementById("player-1-current-amount");
const btnNew = document.querySelector(".btn-new-game");
const btnRoll = document.querySelector(".btn-roll-dice");
const btnHold = document.querySelector(".btn-hold-score");
let scores = [0, 0]; // Using an array to store scores
let currentScore = 0;
let activePlayer;
let Game_state = true;

// Initialize game state
newGame();

// Event listener for resetting the game
btnNew.addEventListener("click", function() {
    newGame();
});

// Event listener for rolling the dice
btnRoll.addEventListener('click', function() {
    if (Game_state) {
        // Generating a random dice roll
        let dice_number = generateDiceNumber();

        // Display dice
        setDiceImage(dice_number);

        // Check for rolled 1
        if (dice_number !== 1) {
            // Add dice to current score
            currentScore += dice_number;
            setcurrentScore();
        } else {
            // Switch to the next player
            switchPlayer();
        }
    }
});

// Event listener for hold button
btnHold.addEventListener('click', function() {
    if (Game_state) {
        setScore();
    }
});
