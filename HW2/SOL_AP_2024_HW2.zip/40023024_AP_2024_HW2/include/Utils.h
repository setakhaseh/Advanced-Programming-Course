#ifndef ADD_H

#define ADD_H
#include <map>
#include <string>
#include <vector>

#include "Account.h"
#include "Person.h"

std::string validateGender(const std::string& gender);
std::string generate_account_number();
std::string generate_cvv2();
std::string generate_expdate();
size_t hash_fingerprint(std::string fingerprint);
bool check_fingerprint(std::string fingerprint, size_t src_fingerprint);
void with_separator(const std::vector<Account*>& vec, std::string sep);
void with_separator(const std::vector<Person*>& vec, std::string sep);
void map_printer(std::map<Account*, Person*> mp);
void map_printer(std::map<Person*, std::vector<Account*>> mp);
void map_printer(std::map<Person*, double> mp);
#endif