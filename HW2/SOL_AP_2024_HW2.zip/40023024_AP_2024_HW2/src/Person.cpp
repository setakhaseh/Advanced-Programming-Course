#include "Person.h"

#include <fstream>
#include <functional>
#include <iostream>

#include "Utils.h"
Person::Person(std::string &name, size_t age, std::string &gender,
               std::string &fingerprint, size_t socioeconomic_rank,
               bool is_alive)
    : name{name},
      age{age},
      gender{validateGender(gender)},
      hashed_fingerprint{hash_fingerprint(fingerprint)},
      socioeconomic_rank{
          socioeconomic_rank > 10
              ? throw std::invalid_argument{"Input rank is outside the "
                                            "specified range"}
              : (socioeconomic_rank < 1
                     ? throw std::invalid_argument{"Input rank is outside the "
                                                   "specified range"}
                     : socioeconomic_rank)},
      is_alive(is_alive) {}
std::string Person::get_name() const { return name; }
size_t Person::get_age() const { return age; }
std::string Person::get_gender() const { return gender; }
size_t Person::get_hashed_fingerprint() const { return hashed_fingerprint; }
size_t Person::get_socioeconomic_rank() const { return socioeconomic_rank; }
bool Person::get_is_alive() const { return is_alive; }
bool Person::set_age(size_t _age) {
  age = _age;
  return age;
}
bool Person::set_socioeconomic_rank(size_t rank) {
  if (!(rank < 11 && rank > 0)) {
    throw std::invalid_argument("Input rank is outside the specified range");
    return false;
  } else {
    socioeconomic_rank = rank;
    return true;
  }
}
bool Person::set_is_alive(bool _is_alive) {
  is_alive = _is_alive;
  return true;
}
std::strong_ordering Person::operator<=>(const Person &other) const {
  return hashed_fingerprint <=> other.hashed_fingerprint;
}
void Person::get_info(std::optional<std::string> file_name) const {
  std::ofstream output_file;
  if (file_name.has_value()) {
    output_file.open(file_name.value());
    if (!output_file.is_open()) {
      throw std::runtime_error("Error opening file.");
    }
  } else {
    output_file.open("default_output.txt");
  }

  output_file << "Name: " << name << "\t"
              << "Age: " << age << "\t"
              << "Gender: " << gender << "\t"
              << "Fingerprint: " << hashed_fingerprint << "\t"
              << "Rank: " << socioeconomic_rank << "\t"
              << "Is alive: " << is_alive << "\t" << std::endl;
}