#include "Account.h"

#include <fstream>
#include <iostream>
#include <stdexcept>

#include "Bank.h"
#include "Person.h"
#include "Utils.h"
Account::Account(const Person* const owner, const Bank* const bank,
                 std::string& password)
    : owner(const_cast<Person*>(owner)),
      bank(bank),
      account_number(generate_account_number()),
      balance(0.0),
      account_status(true),
      CVV2(generate_cvv2()),
      password(password),
      exp_date(generate_expdate()) {}
const Person* Account::get_owner() const { return owner; }
double Account::get_balance() const { return balance; }
std::string Account::get_account_number() const { return account_number; }
bool Account::get_status() const { return account_status; }
std::string Account::get_CVV2(std::string& owner_fingerprint) const {
  if (!check_fingerprint(owner_fingerprint, owner->get_hashed_fingerprint()))
    throw std::invalid_argument("Fingerprints don't match");
  else
    return CVV2;
}
std::string Account::get_password(std::string& owner_fingerprint) const {
  if (!check_fingerprint(owner_fingerprint, owner->get_hashed_fingerprint()))
    throw std::invalid_argument("Fingerprints don't match");
  else
    return password;
}
std::string Account::get_exp_date(std::string& owner_fingerprint) const {
  if (!check_fingerprint(owner_fingerprint, owner->get_hashed_fingerprint()))
    throw std::invalid_argument("Fingerprints don't match");
  else
    return exp_date;
}
bool Account::set_password(std::string& _password,
                           std::string& owner_fingerprint) {
  if (!check_fingerprint(owner_fingerprint, owner->get_hashed_fingerprint()))
    throw std::invalid_argument("Fingerprints don't match");
  else {
    password = _password;
    return true;
  }
}
std::strong_ordering Account::operator<=>(const Account& other) const {
  return account_number <=> other.account_number;
}
void Account::get_info(std::optional<std::string> file_name) const {
  std::ofstream output_file;
  if (file_name.has_value()) {
    output_file.open(file_name.value());
    if (!output_file.is_open()) {
      throw std::runtime_error("Error opening file.");
    } else
      output_file << "Bank: " << bank << "\t"
                  << "Account Number: " << account_number << "\t"
                  << "Balance: " << balance << "\t"
                  << "Account Status: " << account_status << "\t" << std::endl;
  } else {
    std::cout << "Bank: " << bank << "\t"
              << "Account Number: " << account_number << "\t"
              << "Balance: " << balance << "\t"
              << "Account Status: " << account_status << "\t" << std::endl;
  }
}