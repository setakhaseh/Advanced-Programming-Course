#include "Utils.h"

#include <iostream>
#include <random>
#include <string>
#include <vector>
std::string generate_account_number()  // generating a random account number
{
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> distrib(0, 9);

  std::string acc_number = "";
  for (int i = 0; i < 16; ++i) {
    acc_number += std::to_string(distrib(gen));
  }

  return acc_number;
}
std::string validateGender(const std::string& gender) {
  if (gender != "Female" && gender != "Male") {
    throw std::invalid_argument(
        "Error: Invalid gender input. Please provide 'Female' or 'Male'.");
  } else
    return gender;
}
std::string generate_cvv2()  // generating a random CVV2
{
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> distrib(0, 9);

  std::string cvv2_number = "";
  for (int i = 0; i < 4; ++i) {
    cvv2_number += std::to_string(distrib(gen));
  }

  return cvv2_number;
}
std::string generate_expdate()
// generating a random Exp date
{
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> distrib(0, 9);
  std::string expdate = "";
  std::string yy = "";
  std::string mm = "";
  int month;
  for (int i = 0; i < 2; ++i) {
    yy += std::to_string(distrib(gen));
  }
  for (int i = 0; i < 2; ++i) {
    month = distrib(gen);
    if (month < 10) {
      mm = "0";
      mm += std::to_string(month);
    } else
      mm += std::to_string(month);
  }
  expdate += yy;
  expdate += "-";
  expdate += mm;

  return expdate;
}
size_t hash_fingerprint(
    std::string fingerprint)  // convert the string fingerprint into hash
{
  return std::hash<std::string>{}(fingerprint);
}
bool check_fingerprint(std::string fingerprint,
                       size_t src_fingerprint)  // comparing two fingerprints
{
  if (hash_fingerprint(fingerprint) == src_fingerprint)
    return true;
  else
    return false;
}

void with_separator(const std::vector<Account*>& vec,
                    std::string sep)  // printing a vector with account elements
{
  // Iterating over all elements of vector
  for (auto elem : vec) {
    std::cout << elem << sep;
  }

  std::cout << std::endl;
}
void with_separator(const std::vector<Person*>& vec,
                    std::string sep)  // printing a vector with person elements
{
  // Iterating over all elements of vector
  for (auto elem : vec) {
    std::cout << elem << sep;
  }

  std::cout << std::endl;
}
void map_printer(std::map<Account*, Person*> mp)  // printing a map
{
  std::map<Account*, Person*>::iterator it = mp.begin();

  // Iterate through the map and print the elements
  while (it != mp.end()) {
    std::cout << "Key: " << it->first << ", Value: " << it->second << std::endl;
    ++it;
  }
}
void map_printer(std::map<Person*, std::vector<Account*>> mp)  // printing a map
{
  std::map<Person*, std::vector<Account*>>::iterator it = mp.begin();

  // Iterate through the map and print the elements
  while (it != mp.end()) {
    std::cout << "Key: " << it->first << ", Value: ";
    with_separator(it->second, " ");
    ++it;
  }
}
void map_printer(std::map<Person*, double> mp)  // printing a map
{
  std::map<Person*, double>::iterator it = mp.begin();

  // Iterate through the map and print the elements
  while (it != mp.end()) {
    std::cout << "Key: " << it->first << ", Value: " << it->second << std::endl;
    ++it;
  }
}
