#include "Bank.h"

#include <math.h>

#include <iostream>
#include <stdexcept>
#include <vector>

#include "Account.h"
#include "Person.h"
#include "Utils.h"
Bank::Bank(const std::string& bank_name, const std::string& bank_fingerprint)
    : bank_name(bank_name),
      hashed_bank_fingerprint(hash_fingerprint(bank_fingerprint)),
      bank_customers({}),
      bank_accounts({}),
      account_2_customer(),
      customer_2_accounts(),
      customer_2_paid_loan(),
      customer_2_unpaid_loan(),
      bank_total_balance(0),
      bank_total_loan(0) {}
Account* Bank::create_account(Person& owner,
                              const std::string& owner_fingerprint,
                              std::string password) {
  if (!check_fingerprint(owner_fingerprint, owner.get_hashed_fingerprint()))
    throw std::invalid_argument("Fingerprints don't match");
  else {
    Account* new_account = new Account(&owner, this, password);
    bank_accounts.push_back(new_account);
    bank_customers.push_back(&owner);
    account_2_customer[new_account] = &owner;
    customer_2_accounts[&owner].push_back(new_account);
    return new_account;
  }
}
Bank::~Bank() { std::cout << "Destructor" << std::endl; }
bool Bank::delete_account(Account& account,
                          const std::string& owner_fingerprint) {
  if (check_fingerprint(owner_fingerprint,
                        account.owner->get_hashed_fingerprint()) &&
      customer_2_unpaid_loan[account.owner] == 0) {
    bank_total_balance -= account.get_balance();

    for (auto& i : bank_accounts) {
      if (i == &account) {
        std::erase(bank_accounts, i);
        break;
      }
    }
    account_2_customer.erase(&account);
    for (auto& j : customer_2_accounts[account.owner]) {
      if (j == &account) std::erase(customer_2_accounts[account.owner], j);
    }
    return true;
  }

  else {
    throw std::invalid_argument("Fingerprints don't match");
  }
}
bool Bank::delete_customer(Person& owner,
                           const std::string& owner_fingerprint) {
  if (!check_fingerprint(owner_fingerprint, owner.get_hashed_fingerprint())) {
    throw std::invalid_argument("Fingerprints don't match");
  } else if (!customer_2_unpaid_loan[&owner] == 0)
    throw std::invalid_argument(
        "Customer with unpaid loan cannot not be deleted.");

  else {
    for (auto it = bank_customers.begin(); it != bank_customers.end(); ++it) {
      if (*it == &owner) {
        bank_customers.erase(it);
        break;
      }
    }

    for (auto it = account_2_customer.begin();
         it != account_2_customer.end();) {
      if (it->second == &owner) {
        it = account_2_customer.erase(it);
      } else {
        ++it;
      }
    }

    std::vector<Account*> ac;
    for (auto it = customer_2_accounts.begin();
         it != customer_2_accounts.end();) {
      if (it->first == &owner) {
        ac = it->second;
        it = customer_2_accounts.erase(it);
      } else {
        ++it;
      }
    }

    for (size_t i = 0; i < ac.size(); i++) {
      for (auto it = bank_accounts.begin(); it != bank_accounts.end();) {
        if (*it == ac[i]) {
          it = bank_accounts.erase(it);
        } else {
          ++it;
        }
      }
    }

    customer_2_paid_loan.erase(&owner);
    customer_2_unpaid_loan.erase(&owner);
  }
  return true;
}

bool Bank::deposit(Account& account, const std::string& owner_fingerprint,
                   double amount) {
  if (check_fingerprint(owner_fingerprint,
                        account.owner->get_hashed_fingerprint())) {
    account.balance += amount;

    // Add logic to update the unpaid loan map
    // For example, you can add code here to handle the update of the unpaid
    // loan map

    return true;
  } else {
    throw std::invalid_argument("Fingerprints don't match");
  }
}
bool Bank::withdraw(Account& account, const std::string& owner_fingerprint,
                    double amount) {
  double dep{account.get_balance()};
  if (check_fingerprint(owner_fingerprint,
                        account.owner->get_hashed_fingerprint()))
    if (dep >= amount) {
      dep -= amount;
      account.balance = dep;
      return true;
    } else
      throw std::invalid_argument(
          "Withdraw cannot be done due to lack of account balance");
  else
    throw std::invalid_argument("Fingerprints don't match");
}
bool Bank::transfer(Account& source, Account& destination,
                    const std::string& owner_fingerprint,
                    const std::string& CVV2, const std::string& password,
                    const std::string& exp_date, double amount) {
  if ((check_fingerprint(owner_fingerprint,
                         source.owner->get_hashed_fingerprint())) &&
      (CVV2 == source.CVV2) && (password == source.password) &&
      exp_date == source.exp_date) {
    withdraw(source, owner_fingerprint, amount);
    destination.balance += amount;
    return true;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
bool Bank::take_loan(Account& account, const std::string& owner_fingerprint,
                     double amount) {
  double interest = amount * 10 / account.owner->get_socioeconomic_rank();
  if (check_fingerprint(owner_fingerprint,
                        account.owner->get_hashed_fingerprint())) {
    double sum = 0;
    for (auto& j : customer_2_accounts[account_2_customer[&account]]) {
      sum += j->balance;
    }
    if (amount < sum * (10 * account.owner->get_socioeconomic_rank()) / 100) {
      bank_total_loan += amount + interest / 100;
      customer_2_unpaid_loan[account.owner] += amount + interest / 100;
      return true;
    } else
      throw std::invalid_argument(
          "The requested loan is above the maximum loan amount you can request "
          "with respect to your socioeconomic rank");
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
bool Bank::pay_loan(Account& account, double amount) {
  account.balance -= amount;
  bank_total_balance += amount * (account.owner->get_socioeconomic_rank() / 10);
  customer_2_paid_loan[account.owner] += amount;
  customer_2_unpaid_loan[account.owner] -= amount;
  if (customer_2_paid_loan[account.owner] >=
      std::pow(10, account.owner->get_socioeconomic_rank()))
    account.owner->set_socioeconomic_rank(
        account.owner->get_socioeconomic_rank() + 1);
  return true;
}
const std::string& Bank::get_bank_name() const { return bank_name; }
size_t Bank::get_hashed_bank_fingerprint() const {
  return hashed_bank_fingerprint;
}
const std::vector<Person*>& Bank::get_bank_customers(
    std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return bank_customers;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
const std::vector<Account*>& Bank::get_bank_accounts(
    std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return bank_accounts;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
const std::map<Account*, Person*>& Bank::get_account_2_customer_map(
    std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return account_2_customer;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
const std::map<Person*, std::vector<Account*>>&
Bank::get_customer_2_accounts_map(std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return customer_2_accounts;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
const std::map<Person*, double>& Bank::get_customer_2_paid_loan_map(
    std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return customer_2_paid_loan;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
const std::map<Person*, double>& Bank::get_customer_2_unpaid_loan_map(
    std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return customer_2_unpaid_loan;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
double Bank::get_bank_total_balance(std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return bank_total_balance;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
double Bank::get_bank_total_loan(std::string& bank_fingerprint) const {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    return bank_total_loan;
  } else
    throw std::invalid_argument("Fingerprints don't match");
}
bool Bank::set_owner(Account& account, const Person* new_owner,
                     std::string& owner_fingerprint,
                     std::string& bank_fingerprint) {
  if (check_fingerprint(owner_fingerprint,
                        account.owner->get_hashed_fingerprint()))
    if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
      account.owner = const_cast<Person*>(new_owner);
      return true;
    } else
      throw std::invalid_argument("Bank Fingerprints don't match");
  else
    throw std::invalid_argument("Fingerprints don't match");
}
bool Bank::set_account_status(Account& account, bool status,
                              std::string& bank_fingerprint) {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    account.account_status = status;
    return true;
  } else
    throw std::invalid_argument("Bank Fingerprints don't match");
}
bool Bank::set_exp_date(Account& account, std::string& exp_date,
                        std::string& bank_fingerprint) {
  if (check_fingerprint(bank_fingerprint, hashed_bank_fingerprint)) {
    account.exp_date = exp_date;
    return true;
  } else
    throw std::invalid_argument("Bank Fingerprints don't match");
}
void Bank::get_info(std::optional<std::string> file_name) const {
  if (!(file_name.has_value())) {
    std::cout << "Bank Name: " << bank_name << "\t"
              << "Bank Costumers: ";
    with_separator(bank_customers, " ");
    std::cout << "\t"
              << "Bank Accounts: ";
    with_separator(bank_accounts, " ");
    std::cout << "\t"
              << "Account to Costumers: ";
    map_printer(account_2_customer);
    std::cout << "\t"
              << "Costumer to Accounts: ";
    map_printer(customer_2_accounts);
    std::cout << "\t"
              << "Costumer to Paid Loans: ";
    map_printer(customer_2_paid_loan);
    std::cout << "\t"
              << "Costumer to Unpaid Loans: ";
    map_printer(customer_2_unpaid_loan);
    std::cout << "   Info is done!" << std::endl;
  }
}