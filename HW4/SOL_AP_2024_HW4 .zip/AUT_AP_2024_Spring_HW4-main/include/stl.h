#ifndef STL_H
#define STL_H

#include <algorithm>
#include <functional>
#include <limits>
#include <numeric>
#include <set>
#include <string>
#include <vector>

void initial_vector_with_3_multiples(std::vector<int>& v, size_t size)
{
    v.resize(size);
    std::generate(v.begin(), v.end(), [n = 1]() mutable { return n++ * 3; });
}

int count_unique_above(std::vector<int> v, int n)
{
    std::set<int> set(v.begin(), v.end());
    int num = std::count_if(set.begin(), set.end(), [&](int x) { return x > n; });
    return num;
}

std::string vector_to_string(std::vector<int> v, char separator)
{
    return std::accumulate(v.rbegin(), v.rend(), std::string(),
        [&](std::string acc, int x) {
            return acc.empty() ? std::to_string(x) : acc + separator + std::to_string(x);
        });
}

void square_elements(std::vector<int>& v)
{

    // Create a new vector of longs
    std::vector<long> _v(v.begin(), v.end());
    std::transform(_v.begin(), _v.end(), _v.begin(), [](int x) {
        return x * x;
    });

    // Now, replace v_int with v_long
    v = std::vector<int>(_v.begin(), _v.end());
}

void copy_if_even(const std::vector<int>& source, std::vector<int>& destination)
{
    destination.clear();
    std::copy_if(source.begin(), source.end(), std::back_inserter(destination),
        [](int x) { return x % 2 == 0; });
}

#endif // STL_H