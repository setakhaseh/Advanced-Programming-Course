#include "server.h"
#include "crypto.h"

std::vector<User> Server::get_users() const
{
    return users;
}

std::map<std::string, std::string> Server::get_public_keys() const
{
    return public_keys;
}

std::vector<Message*> Server::get_messages() const
{
    return messages;
}

User Server::create_user(std::string username)
{
    for (const User& user : users) {
        if (user.get_username() == username) {
            throw std::logic_error("Username already exists.");
        }
    }

    std::string public_key {}, private_key {};
    crypto::generate_key(public_key, private_key);

    users.push_back(User(username, private_key, this));
    public_keys[username] = public_key;

    return users.back();
}

bool Server::create_message(Message* msg, std::string signature)
{
    bool authentic { false };
    for (const User& user : users)
        if (user.get_username() == msg->get_receiver())
            for (const User& _user : users) {
                if (_user.get_username() == msg->get_sender()) {
                    User sender { _user };
                    authentic = crypto::verifySignature(
                        public_keys[sender.get_username()], "my data", signature);
                    if (authentic)
                        messages.push_back(msg);
                }
            }
    return authentic;
}

std::vector<Message*> Server::get_all_messages_from(std::string username)
{
    std::vector<Message*> user_messages;
    std::copy_if(messages.begin(), messages.end(), std::back_inserter(user_messages),
        [username](Message* msg) { return msg->get_sender() == username; });
    return user_messages;
}

std::vector<Message*> Server::get_all_messages_to(std::string username)
{
    std::vector<Message*> user_messages;
    std::copy_if(messages.begin(), messages.end(), std::back_inserter(user_messages),
        [username](Message* msg) { return msg->get_receiver() == username; });
    return user_messages;
}

std::vector<Message*> Server::get_chat(std::string user1, std::string user2)
{
    std::vector<Message*> chat_messages;
    std::copy_if(messages.begin(), messages.end(), std::back_inserter(chat_messages),
        [user1, user2](Message* msg) {
            return (msg->get_sender() == user1 && msg->get_receiver() == user2) || (msg->get_sender() == user2 && msg->get_receiver() == user1);
        });
    return chat_messages;
}
void Server::sort_msgs(std::vector<Message*>& msgs)
{
    std::sort(msgs.begin(), msgs.end(), [](Message* a, Message* b) {
        return a->get_time() < b->get_time();
    });
}