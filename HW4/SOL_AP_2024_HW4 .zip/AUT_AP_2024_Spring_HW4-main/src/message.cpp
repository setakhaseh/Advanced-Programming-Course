#include "message.h"
#include <ctime>
#include <iostream>

Message::Message(std::string type, std::string sender, std::string receiver)
    : type(type)
    , sender(sender)
    , receiver(receiver)
{
    std::time_t now = std::time(0);
    time = std::ctime(&now);
    time.erase(time.find_last_not_of(" \n\r\t") + 1);
}

Message::Message()
    : type {}
    , sender {}
    , receiver {}
{
    std::time_t now = std::time(0);
    time = std::ctime(&now);
    time.erase(time.find_last_not_of(" \n\r\t") + 1);
}

std::string Message::get_type() const
{
    return type;
}

std::string Message::get_sender() const
{
    return sender;
}

std::string Message::get_receiver() const
{
    return receiver;
}

std::string Message::get_time() const
{
    return time;
}

void Message::print(std::ostream& os) const
{
    os << "*************************" << std::endl;
    os << sender << " -> " << receiver << std::endl;
    os << "message type: " << type << std::endl;
    os << "message time: " << time;
    os << "*************************" << std::endl;
}

std::ostream& operator<<(std::ostream& os, const Message& msg)
{
    msg.print(os);
    return os;
}
TextMessage::TextMessage(std::string text, std::string sender, std::string receiver)
    : Message("text", sender, receiver)
    , text(text)
{
}

void TextMessage::print(std::ostream& os) const
{
    os << "*************************" << std::endl;
    os << get_sender() << " -> " << get_receiver() << std::endl;
    os << "message type: " << get_type() << std::endl;
    os << "message time: " << get_time() << std::endl;
    os << "text: " << text << std::endl;
    os << "*************************" << std::endl;
}

std::string TextMessage::get_text() const
{
    return text;
}
VoiceMessage::VoiceMessage(std::string sender, std::string receiver)
    : Message("voice", sender, receiver)
{
    for (int i = 0; i < 5; ++i) {
        voice.push_back(static_cast<unsigned char>(rand() % 256));
    }
}

void VoiceMessage::print(std::ostream& os) const
{
    os << "*************************" << std::endl;
    os << get_sender() << " -> " << get_receiver() << std::endl;
    os << "message type: " << get_type() << std::endl;
    os << "message time: " << get_time() << std::endl;
    os << "voice: ";
    for (unsigned char byte : voice) {
        os << static_cast<int>(byte) << " ";
    }
    os << std::endl;
    os << "*************************" << std::endl;
}

std::vector<unsigned char> VoiceMessage::get_voice() const
{
    return voice;
}
