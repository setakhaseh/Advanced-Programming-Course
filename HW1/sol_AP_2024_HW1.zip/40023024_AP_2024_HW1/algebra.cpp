#include<iostream>
#include<vector>
#include<optional>
#include<random>
#include <iomanip>
#include <format>
#include"algebra.h"
int main()
{

}

