#!/bin/bash
# Calculate start time
start_time=$(date -u +%T)
# Assign input arguments to variables
source_path=$1
destination_path=$2
# Check if the user has provided enough arguments
if [ $#  -lt 2  ]; then
    echo "ERROR: The required inputs are not provided. Please try again."
    exit 1
fi
# Set default compression level
compression_level=1

# Parse command-line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -c|--compression)
        compression_level="$2"
        shift
        shift
        ;;
        *)
        source_path="$1"
        destination_path="$2"
        shift
        shift
        ;;
    esac
done
# Extract the directory name from the path
directoryname="${source_path##*/}"
#Auxiliary details for the name of the zip
underline="_"
# Capture the current date and time
Date=$(date +%Y-%m-%d)
Time=$(date -u +%T)
# Machine Information
machine_info=$(uname -a)
# Count the number of files and directories backed up
total_files=$(find "$source_path" -type f | wc -l)
total_directories=$(find "$source_path" -type d | wc -l)
#making the zip 
zip -$compression_level  -r  $Date$underline$directoryname $source_path 
#move the zip to the destination directory
mv $Date$underline$directoryname".zip" $destination_path
#Display backup completion message
echo "Backup of $source_path completed successfully."
echo "Saved to $Date$underline$directoryname.zip"
# Calculate end time
end_time=$(date -u +%T)
# Calculate duration
start_seconds=$(date -d "$start_time" +%s)
end_seconds=$(date -d "$end_time" +%s)
duration_seconds=$((end_seconds - start_seconds))
duration=$(date -u -d @$duration_seconds +"%M minutes %S seconds")
# Create the backup log
log_file="$destination_path/backup_log.txt"
echo "Backup Log Report" > "$log_file"
echo "" >> "$log_file"
echo "Date: $Date" >> "$log_file"
echo "Time: $Time UTC " >> "$log_file"
echo "" >> "$log_file"
echo "Machine Information:" >> "$log_file"
echo "Operating System: $machine_info" >> "$log_file"
echo "" >> "$log_file"
echo "Backup Details:" >> "$log_file"
echo "Source Path: $source_path" >> "$log_file"
echo "Destination Path: $destination_path" >> "$log_file"
echo "Compression Level: $compression_level" >> "$log_file"
echo "Files Backed Up: $total_files" >> "$log_file"
echo "Directories Backed Up: $total_directories" >> "$log_file"
echo "" >> "$log_file"
echo "Backup Summary:" >> "$log_file"
echo "Start Time: $start_time UTC" >> "$log_file"
echo "End Time: $end_time UTC" >> "$log_file"
echo "Total Duration: $duration" >> "$log_file"

echo "Backup log generated successfully at $log_file"
