#include<iostream>
#include<vector>
#include<optional>
#include<random>
#include<format>
#include <iomanip>
namespace algebra 
{
    // Matrix data structure
    template<typename T>
    using MATRIX = std::vector<std::vector<T>>;

    // Matrix initialization types
    enum class MatrixType { Zeros, Ones, Identity, Random };
    // Function template for matrix initialization
    template<typename T>
    MATRIX<T> create_matrix(std::size_t rows, std::size_t columns, std::optional<MatrixType> type = MatrixType::Zeros,
    std::optional<T> lowerBound = std::nullopt, std::optional<T> upperBound = std::nullopt)
    {
        //Errors due to wrong input
        if (type == MatrixType::Identity && rows != columns) 
           throw std::invalid_argument("Identity matrix must be square (rows == columns).");
        if (type ==MatrixType::Random && (!lowerBound.has_value() && !upperBound.has_value()))
            throw std::invalid_argument("Both lowerBound and upperBound must be specified for Random matrix type.");
        if (type == MatrixType::Random && lowerBound > upperBound)
            throw std::invalid_argument("LowerBound must be less than upperBound for Random matrix type.");
        MATRIX<T> matrix(rows, std::vector<T>(columns));
        if (type==MatrixType::Zeros)
            for (auto& rows : matrix) 
                std::fill(rows.begin(), rows.end(), static_cast<T>(0));
        else if (type ==MatrixType::Ones)
            {for (auto& rows: matrix)
                std::fill(rows.begin(), rows.end(), static_cast<T>(1));}
        else if (type == MatrixType::Identity)
        {
            for (std::size_t i = 0; i < rows; ++i) {
                for (std::size_t j = 0; j < columns; ++j) {
                    matrix[i][j] = (i == j) ? static_cast<T>(1) : static_cast<T>(0);
                }
            }
        }
        else if (type == MatrixType::Random) 
        {
            std::random_device rd;
            std::mt19937 gen(rd());
            std::uniform_real_distribution<double> dis(lowerBound.value(), upperBound.value());

            for (auto& row : matrix) {
                for (auto& element : row) {
                    element = static_cast<T>(dis(gen));
                }
            }
        }
    return matrix;    
    }
    // Function template for matrix initialization
    template<typename T>
    void display(const MATRIX<T>& matrix) {
        for (const auto& row : matrix) {
            for (const auto& element : row) {
                std::cout << std::format("{:>7}", element); // Adjust width as needed
            }
            std::cout << '\n';
        }
    }
     // Function template for matrix initialization
    template<typename T>
     // Function template for sum and sub opertion on two matrices
    MATRIX<T> sum_sub(const MATRIX<T>& matrixA, const MATRIX<T>& matrixB, std::optional<std::string> operation = std::nullopt)
    {
        if (matrixA.size() != matrixB.size() || matrixA[0].size() != matrixB[0].size())
            throw std::invalid_argument ("Rows and columns should have the same value!");

        MATRIX<T> sum_sub(matrixA.size(), std::vector<T>(matrixA[0].size()));

        if (!operation.has_value() || *operation == "sum")
        {
            for (std::size_t i = 0; i < matrixA.size(); ++i)
            {
                for (std::size_t j = 0; j < matrixA[0].size(); ++j)
                {
                    sum_sub[i][j] = matrixA[i][j] + matrixB[i][j];
                }
            }
        }
        else if (*operation == "sub")
        {
            for (std::size_t i = 0; i < matrixA.size(); ++i)
            {
                for (std::size_t j = 0; j < matrixA[0].size(); ++j)
                {
                    sum_sub[i][j] = matrixA[i][j] - matrixB[i][j];
                }
            }
        }

        return sum_sub;
    }
    // Function template for matrix initialization
    template<typename T>
    // Function template for multiply(scalar) opertion on a given matrix
    MATRIX<T> multiply(const MATRIX<T>& matrix, const T scalar)
    {
        MATRIX<T> multiply(matrix.size(), std::vector<T>(matrix[0].size()));
        for (std::size_t i = 0; i < matrix.size(); ++i)
            {
                for (std::size_t j = 0; j < matrix[0].size(); ++j)
                {
                    multiply[i][j] = matrix[i][j]*scalar;
                }
            }
        return multiply;
    }
    // Function template for matrix initialization
    template<typename T>
    // Function template for multiply opertion on two matrices
    MATRIX<T> multiply(const MATRIX<T>& matrixA, const MATRIX<T>& matrixB)
    {
        if (matrixA[0].size() != matrixB.size())
            throw std::invalid_argument ("The number of columns in matrixA doesn't match the number of rows in matrixB!");
        MATRIX<T> multiply(matrixA.size(), std::vector<T>(matrixB[0].size()));
        for (std::size_t i = 0; i < matrixA.size(); ++i)
            {
                for (std::size_t j = 0; j < matrixB[0].size(); ++j)
                {
                    multiply[i][j]=0;
                for (std::size_t n = 0; n < matrixB.size(); ++n)
                {
                    multiply[i][j] = matrixA[i][n]*matrixB[n][j]+multiply[i][j];
                }
                }
            }
        return multiply;
    }
    // Function template for matrix initialization
    template<typename T>
    // Function template for hadamard_product opertion on two matrices
    MATRIX<T> hadamard_product(const MATRIX<T>& matrixA, const MATRIX<T>& matrixB)
    {
        if (matrixA.size()!= matrixB.size() && matrixA[0].size()!= matrixB[0].size())
            throw std::invalid_argument ("The matrices matrixA and matrixB must be of the same size!");
        MATRIX<T> hadamard_product(matrixA.size(), std::vector<T>(matrixB[0].size()));
        for (std::size_t i = 0; i < hadamard_product.size(); ++i)
            {
                for (std::size_t j = 0; j < hadamard_product[0].size(); ++j)
                {
                    hadamard_product[i][j] = matrixA[i][j]*matrixB[i][j];
                }
            }
        return hadamard_product;
    }
    // Function template for matrix initialization
    template<typename T>
    // Function template for transpose opertion on a matrix
    MATRIX<T> transpose(const MATRIX<T>& matrix)
    {
        if (matrix.size() == 0)
            throw std::invalid_argument ("The matrices matrixA and matrixB must be of the same size!");
        MATRIX<T> transpose(matrix[0].size(), std::vector<T>(matrix.size()));
        for (std::size_t i = 0; i < transpose.size(); ++i)
            {
                for (std::size_t j = 0; j < transpose[0].size(); ++j)
                {
                    transpose[i][j] = matrix[j][i];
                }
            }
        return transpose;
    }
    // Function template for matrix initialization
    template<typename T>
    // Function template for trace opertion on a matrix
    T trace(const MATRIX<T>& matrix)
    {
        if (matrix.size() != matrix[0].size())
            throw std::invalid_argument (" The trace can only be calculated for square matrices!");
        T trace{};
        for (std::size_t i = 0; i < matrix.size(); ++i)
            {
                    trace = matrix[i][i]+trace;
            }
        return trace;
    }
    // Function template for matrix initialization
    template<typename T>
    // Function template for calculating the deteminant of a matrix
    double determinant(const MATRIX<T>& matrix) {
        // Check if the matrix is square
        if (matrix.size() != matrix[0].size()) {
            throw std::invalid_argument ("Cannot calculate determinant for a non-square matrix.");
        }
        // Base case: 1x1 matrix
        if (matrix.size() == 1) {
            return matrix[0][0];
        }

        double det{};
        MATRIX<T> submatrix(matrix.size() - 1, std::vector<T>(matrix.size() - 1));

        for (std::size_t i = 0; i < matrix.size(); ++i) {
            // Get submatrix for minor calculation
            for (std::size_t j = 1; j < matrix.size(); ++j) {
                for (std::size_t k = 0; k < matrix.size(); ++k) {
                    if (k < i) {
                        submatrix[j - 1][k] = matrix[j][k];
                    } else if (k > i) {
                        submatrix[j - 1][k - 1] = matrix[j][k];
                    }
                }
            }

            // Calculate the determinant 
            double sign = (i % 2 == 0) ? 1.0 : -1.0;
            det += sign * matrix[0][i] * determinant(submatrix);
        }

        return det;
    }
    template<typename T>
    MATRIX<double> inverse(const MATRIX<T>& matrix)
    {
        MATRIX<double> inverse(matrix.size(), std::vector<double>(matrix[0].size()));
        MATRIX<double> identityMatrix = create_matrix<double>(matrix.size(), matrix.size(), MatrixType::Identity);
        for (std::size_t i = 0; i < matrix.size(); ++i)
            {
                for (std::size_t j = 0; j < matrix[0].size(); ++j)
                {
                    inverse[i][j] = matrix[i][j];
                }
            }
        // Forward elimination
        for (std::size_t i = 0; i < inverse.size(); ++i) {
            for (std::size_t j = 0; j < inverse[0].size(); ++j) {
                if (i == j) {
                    for (std::size_t k = 0; k < inverse[0].size(); ++k){
                    inverse[j][k] = inverse[j][k] / inverse[j][k];
                    identityMatrix[j][k] = identityMatrix[j][i] / inverse[j][k];}
                } else if (i < j && inverse[j][i]!= 0 && j!=inverse[0].size()-1) {
                    for (std::size_t k = 0; k < inverse[0].size(); ++k){ 
                    inverse[j][k] = inverse[j][k] + inverse[j+1][k] * (inverse[j][k] * -1 / inverse[j+1][k]);
                    identityMatrix[j][k] = identityMatrix[j][k] + inverse[j+1][k] * (inverse[j][k] * -1 / inverse[j+1][k]);}
                } 
                else if(i < j && inverse[j][i]!= 0 && j==inverse[0].size()-1)
                {
                   for (std::size_t k = 0; k < inverse[0].size(); ++k){ 
                    inverse[j][k] = inverse[j][k] + inverse[0][k] * (inverse[j][k] * -1 / inverse[0][k]);
                    identityMatrix[j][k] = identityMatrix[j][k] + inverse[0][k] * (inverse[j][k] * -1 / inverse[0][k]);} 
                }
            }
        }

        // Backward elimination
        for (std::size_t i = inverse.size() - 1; i > 0; --i) {
            for (std::size_t j = inverse[0].size() - 1; j > 0; --j) {
                if (i > j && inverse[j][i - 1] != 0) {
                    inverse[j][i] = inverse[j][i] + inverse[j-1][i] * (inverse[j][i] * -1 / inverse[j-1][i]);
                    identityMatrix[j][i] = identityMatrix[j][i] + inverse[j-1][i] * (inverse[j][i] * -1 / inverse[j-1][i]);
                } 
            }
        }

        return identityMatrix;
    }

}
